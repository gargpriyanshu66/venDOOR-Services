const mongoose = require('mongoose')

const reviewSchema = new mongoose.Schema({
    autoId: { type: Number, default: 0 },
    customerId: { type:mongoose.Schema.Types.ObjectId,ref:'customer',default:null },
    serviceId: { type:mongoose.Schema.Types.ObjectId,ref:'service',default:null },
    providerId: {type:mongoose.Schema.Types.ObjectId,ref:'serviceProvider',default:null },
    review: { type: String, default: '' },
    rating: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now() },
    status: { type: Boolean, default: true }
})

module.exports = mongoose.model('review', reviewSchema)