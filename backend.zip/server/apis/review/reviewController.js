
const reviewModel = require('./reviewModel')

const add = async (req, res) => {

    let validation = ""

    if (!req.body.customerId) {
        validation += "customerId is required "

    }
    if (!req.body.serviceId) {
        validation += "serviceId is required "

    }
    if (!req.body.providerId) {
        validation += "providerId is required "

    }
    if (!req.body.review) {
        validation += "review is required"

    }
    if (!req.body.rating) {
        validation += "rating is required"

    }
    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error : " + validation
        })

    }
    else {

        let total = await reviewModel.countDocuments()
        let review = new reviewModel({

            autoId: total + 1,
            customerId: req.body.customerId,
            serviceId: req.body.serviceId,
            providerId: req.body.providerId,
            review: req.body.review,
            rating: req.body.rating
        })
        review.save()

            .then((result) => {

                res.send({
                    success: true,
                    status: 200,
                    message: "New review added",
                    data: result
                })
            })
            .catch((err) => {

                res.send({
                    success: false,
                    status: 500,
                    message: err.message,

                })
            })


    }
}


const all = (req, res) => {

    req.body.status = true

    reviewModel.find(req.body)
        .populate('customerId')
        .populate('serviceId')
        .populate('providerId')
        .sort({createdAt:-1})
        .exec()

        .then((result) => {
            res.send({
                success: true,
                status: 200,
                message: "all documents loaded",
                total: result.length,
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })
}


const single = (req, res) => {

    reviewModel.findOne({ _id: req.body._id })
        .populate('customerId')
        .populate('serviceId')
        .populate('providerId')
        .exec()

        .then((result) => {

            if (result == null) {

                res.send({

                    sucess: false,
                    status: 422,
                    message: "review not found"

                })
            }

            res.send({
                success: true,
                status: 200,
                message: "single document loaded",
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })

}


const deletefun = (req, res) => {

    let validation = ""
    if (!req.body._id) {
        validation += "_id is required"
    }

    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error: " + validation
        })
    }

    else {

        reviewModel.findOne({ _id: req.body._id }).exec()

            .then((reviewData) => {

                if (reviewData == null) {

                    res.send(res.send({
                        success: false,
                        status: 404,
                        message: "Review not found"
                    })

                    )
                }

                else {

                    reviewData.status = false

                    reviewData.save()
                        .then((result) => {

                            res.send({
                                success: true,
                                status: 200,
                                message: "Review delted",

                            })
                        })
                        .catch((err) => {

                            res.send({

                                success: false,
                                status: 500,
                                message: err.message
                            })

                        })
                }

            })
            .catch((err) => {

                res.send({
                    success: false,
                    status: 500,
                    message: err.message

                })
            })
    }



}



module.exports = { add, all, single, deletefun }