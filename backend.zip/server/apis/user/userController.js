
const userModel = require('./userModel')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const SECRETKEY = "123238787@#dhskhdjshd"

const login = (req, res) => {

    let validation = ""

    if (!req.body.email) {
        validation += "email is required"
    }
    if (!req.body.password) {
        validation += "password is required"
    }

    if (!!validation) {
        res.send({

            success: false,
            status: 404,
            message: "validation error:" + validation

        })
    }
    else {

        userModel.findOne({ email: req.body.email }).exec()
            .then((userData) => {

                if (userData == null) {

                    res.send({

                        success: false,
                        status: 404,
                        message: "User Account does not exist"

                    })
                }
                else {

                    if (bcrypt.compareSync(req.body.password, userData.password)) {


                        if (userData.status) {

                            let payload = {

                                _id: userData._id,
                                name: userData.name,
                                email: userData.email,
                                userType: userData.userType
                            }
                            let token = jwt.sign(payload, SECRETKEY)

                            res.send({

                                success: true,
                                status: 200,
                                message: "Login Successfully",
                                data: userData,
                                token: token

                            })


                        }
                        else {

                            res.send({

                                success: false,
                                status: 403,
                                message: "User Account inactive, Contact Admin "

                            })


                        }
                    }

                    else {
                        res.send({

                            success: false,
                            status: 403,
                            message: "Invalid "

                        })


                    }
                }
            })
            .catch((err) => {

                res.send({

                    success: false,
                    status: 500,
                    message: err.message

                })

            })
    }
}



const changePassword = (req, res) => {


    let validation = ""

    if (!req.body._id) {
        validation += "_id is required "
    }
    if (!req.body.currentPassword) {
        validation += "currentPassword is required"
    }

    if (!req.body.newPassword) {
        validation += "newPassword is required"
    }

    if (!!validation) {
        res.send({

            success: false,
            status: 404,
            message: "validation error:" + validation

        })
    }
    else {

        userModel.findOne({ _id: req.body._id }).exec()

            .then((userData) => {
                if (userData == null) {

                    res.send({

                        success: false,
                        status: 404,
                        message: "User Account doesnot exist"

                    })

                }

                if (!bcrypt.compareSync(req.body.currentPassword, userData.password)) {

                    res.send({
                        success: false,
                        status: 404,
                        message: "Incorrect Current Password "

                    })

                }
                else {

                    userData.password = bcrypt.hashSync(req.body.newPassword, 10)
                    userData.save()
                        .then(() => {

                            res.send({
                                success: true,
                                status: 200,
                                message: "Password Changed"

                            })
                        })

                        .catch((err) => {

                            res.send({
                                success: false,
                                status: 404,
                                message: "Password doesnot changed"

                            })

                        })
                }


            })
            .catch((err) => {

                res.send({
                    success: false,
                    status: 422,
                    message: err.message

                })

            })
    }

}

module.exports = { login, changePassword }
