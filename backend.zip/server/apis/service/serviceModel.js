const mongoose = require('mongoose')

const serviceSchema = new mongoose.Schema({
    autoId: { type: Number, default: 0 },
    name: { type: String, default: '' },
    description: { type: String, default: '' },
    price: { type: Number, default: 0 },
    image: [{type: String, default: '' }],
    categoryId: { type:mongoose.Schema.Types.ObjectId,ref:'category',default:null },
    serviceProviderId: { type:mongoose.Schema.Types.ObjectId,ref:'serviceProvider',default:null },
    createdAt: { type: Date, default: Date.now() },
    status: { type: Boolean, default: true }
})

module.exports = mongoose.model('service', serviceSchema)