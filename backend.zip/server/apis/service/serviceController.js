const { uploadImg } = require('../../utilities/helper')
const serviceModel = require('./serviceModel')

const add = async (req, res) => {

    let validation = ""

    if (!req.body.name) {
        validation += "Name is required "

    }
    if (!req.body.description) {
        validation += "description is required "

    }
    if (!req.body.price) {
        validation += "Price is required "

    }
    if (!req.body.categoryId) {
        validation += "categoryId is required "

    }
    if (!req.body.serviceProviderId) {
        validation += "serviceProviderId is required "

    }
    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error : " + validation
        })

    }
    else {

        let total = await serviceModel.countDocuments()
         let imgUrl = "Image not uploaded";
                try {
                    imgUrl = await uploadImg(req.file.buffer);
                } catch (err) {
                    console.error("Cloudinary upload error:", err);
                    return res.status(500).json({
                        success: false,
                        message: "Image upload failed: " + err.message
                    });
                }
        let service = new serviceModel({

            autoId: total + 1,
            name: req.body.name,
            description: req.body.description,
            price: req.body.price,
            categoryId: req.body.categoryId,
            serviceProviderId: req.body.serviceProviderId,
            image: imgUrl

        })
        service.save()

            .then((result) => {

                res.send({
                    success: true,
                    status: 200,
                    message: "New service added",
                    data: result
                })
            })
            .catch((err) => {

                res.send({
                    success: false,
                    status: 500,
                    message: err.message,

                })
            })


    }
}

const all = (req, res) => {
    req.body.status = true

    serviceModel.find(req.body)
        .populate('categoryId')
        .populate('serviceProviderId')
        .sort({ createdAt: -1 })
        .exec()

        .then((result) => {
            res.send({
                success: true,
                status: 200,
                message: "all documents loaded",
                total: result.length,
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })
}


const single = (req, res) => {

    serviceModel.findOne({ _id: req.body._id })
        .populate('categoryId')
        .populate('serviceProviderId')
        .exec()

        .then((result) => {

            if (result == null) {

                res.send({

                    sucess: false,
                    status: 422,
                    message: "service not found"

                })
            }

            res.send({
                success: true,
                status: 200,
                message: "single document loaded",
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })

}

const update = (req, res) => {

    let validation = ""
    if (!req.body._id) {
        validation += "_id is required"
    }

    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error: " + validation
        })
    }

    else {

        serviceModel.findOne({ _id: req.body._id }).exec()

            .then(async(serviceData) => {

                if (serviceData == null) {

                    res.send(res.send({
                        success: false,
                        status: 404,
                        message: "Service not found"
                    })

                    )
                }

                else {

                    if (!!req.body.name) serviceData.name = req.body.name
                    if (!!req.body.description) serviceData.description = req.body.description
                    if (!!req.body.price) serviceData.price = req.body.price
                    if (!!req.body.categoryId) serviceData.categoryId = req.body.categoryId
                    if (!!req.body.serviceProviderId) serviceData.serviceProviderId = req.body.serviceProviderId
                    if (!!req.file) {
                        // serviceData.image = 'serviceImage/' + req.file.filename
                          try {
                                    imgUrl = await uploadImg(req.file.buffer);
                                } catch (err) {
                                    console.error("Cloudinary upload error:", err);
                                    return res.status(500).json({
                                        success: false,
                                        message: "Image upload failed: " + err.message
                                    });
                                }
                    }
                    serviceData.save()
                        .then((result) => {

                            res.send({
                                success: true,
                                status: 200,
                                message: "Document updated",
                                data: result
                            })
                        })
                        .catch((err) => {

                            res.send({

                                success: false,
                                status: 500,
                                message: err.message
                            })

                        })
                }

            })
            .catch((err) => {

                res.send({
                    success: false,
                    status: 500,
                    message: err.message

                })
            })
    }
}

const deletefun = (req, res) => {

    let validation = ""
    if (!req.body._id) {
        validation += "_id is required"
    }

    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error: " + validation
        })
    }

    else {

        serviceModel.findOne({ _id: req.body._id }).exec()

            .then((serviceData) => {

                if (serviceData == null) {

                    res.send(res.send({
                        success: false,
                        status: 404,
                        message: "service not found"
                    })

                    )
                }

                else {

                    serviceData.status = false

                    serviceData.save()
                        .then((result) => {

                            res.send({
                                success: true,
                                status: 200,
                                message: "Document delted",

                            })
                        })
                        .catch((err) => {

                            res.send({

                                success: false,
                                status: 500,
                                message: err.message
                            })

                        })
                }

            })
            .catch((err) => {

                res.send({
                    success: false,
                    status: 500,
                    message: err.message

                })
            })
    }

}

module.exports = { add, all, single, update, deletefun }