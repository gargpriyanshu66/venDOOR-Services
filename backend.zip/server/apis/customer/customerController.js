const userModel = require('../user/userModel')
const customerModel = require('./customerModel')
const bcrypt = require('bcrypt')




const add = async (req, res) => {

    let validation = ""

    if (!req.body.name) {
        validation += "Name is required "

    }
    if (!req.body.email) {
        validation += "email is required "

    }
    if (!req.body.password) {
        validation += "password is required "

    }
    if (!req.body.contact) {
        validation += "contact is required "

    }
    if (!req.body.address) {
        validation += "address is required"

    }

    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error : " + validation
        })

    }
    else {

        let olduser = await userModel.findOne({ email: req.body.email })

        if (olduser == null) {
            let userTotal = await userModel.countDocuments()
            let userObj = new userModel({
                autoId: userTotal + 1,
                name: req.body.name,
                email: req.body.email,
                password: bcrypt.hashSync(req.body.password, 10)
            })

            userObj.save()
                .then(async (savedUser) => {
                    let customerTotal = await customerModel.countDocuments()
                    let customerObj = new customerModel({

                        autoId: customerTotal + 1,
                        name: req.body.name,
                        email: req.body.email,
                        contact: req.body.contact,
                        address: req.body.address,
                        userId: savedUser._id

                    })
                    customerObj.save()

                        .then((savedCustomer) => {
                            savedUser.customerId = savedCustomer._id
                            savedUser.save()
                                .then((result) => {

                                    res.send({

                                        success: true,
                                        status: 200,
                                        message: "New customer added",
                                        data: result
                                    })
                                })


                        })
                        .catch((err) => {

                            res.send({
                                success: false,
                                status: 500,
                                message: err.message,

                            })
                        })
                })
                .catch((err) => {
                    res.send({
                        success: false,
                        status: 500,
                        message: err.message
                    })


                })

        }

        else {

            res.send({
                success: false,
                status: 409,
                message: "User already exists"
            })

        }



    }
}


const all = (req, res) => {

    customerModel.find(req.body)
        .populate('userId')
        .sort({ createdAt: -1 })
        .exec()

        .then((result) => {
            res.send({
                success: true,
                status: 200,
                message: "all documents loaded",
                total: result.length,
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })
}


const single = (req, res) => {

    customerModel.findOne({ _id: req.body._id })
        .populate('userId')
        .exec()

        .then((result) => {

            if (result == null) {

                res.send({

                    sucess: false,
                    status: 422,
                    message: "Customer not found"

                })
            }

            res.send({
                success: true,
                status: 200,
                message: "single document loaded",
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })

}

const update = async (req, res) => {

    let validation = ""
    if (!req.body._id) {
        validation += "_id is required"
    }

    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error: " + validation
        })
    }




    else {

        let prevUser = await userModel.findOne({
            $and: [
                { email: req.body.email },
                { customerId: { $ne: req.body._id } }
            ]
        })

        if (!!prevUser) {
            res.send({
                success: false,
                status: 409,
                message: "Email Already Exists"
            })
        }
        else {
            userModel.findOne({ customerId: req.body._id }).exec()

                .then((userData) => {

                    if (userData == null) {

                        res.send({
                            success: false,
                            status: 404,
                            message: "User not found"
                        })
                    }

                    else {

                        if (!!req.body.name) userData.name = req.body.name
                        if (!!req.body.email) userData.email = req.body.email

                        userData.save()
                            .then((updateCustomer) => {
                                customerModel.findOne({ _id: req.body._id }).exec()

                                    .then((customerData) => {

                                        if (customerData == null) {
                                            res.send({
                                                success: false,
                                                status: 404,
                                                message: "customer not found"
                                            })
                                        }

                                        else {
                                            if (!!req.body.name) customerData.name = req.body.name
                                            if (!!req.body.email) customerData.email = req.body.email
                                            if (!!req.body.contact) customerData.contact = req.body.contact
                                            if (!!req.body.address) customerData.address = req.body.address


                                            customerData.save()
                                                .then((result) => {

                                                    res.send({
                                                        success: true,
                                                        status: 200,
                                                        message: "Customer Profile updated",
                                                        data: result
                                                    })
                                                })
                                                .catch((err) => {
                                                    res.send({

                                                        success: false,
                                                        status: 500,
                                                        message: err.message
                                                    })

                                                })
                                        }

                                    })

                            })
                    }

                })
                .catch((err) => {

                    res.send({
                        success: false,
                        status: 500,
                        message: err.message

                    })
                })

        }


    }
}

const changeStatus = async (req, res) => {
    let validations = ""
    if (!req.body._id) {
        validations += "_id is required "
    }
    if (!req.body.status) {
        validations += "status is required "
    }

    if (!!validations) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error : " + validations
        })
    }
    else {

        userModel.findOne({ customerId: req.body._id }).exec()
            .then((userData) => {
                if (userData == null) {
                    res.send({
                        success: false,
                        status: 404,
                        message: "User Not Found"
                    })
                }
                else {
                    userData.status = req.body.status


                    userData.save()
                        .then((updatedUser) => {
                            customerModel.findOne({ _id: req.body._id }).exec()
                                .then((customerData) => {
                                    if (customerData == null) {
                                        res.send({
                                            success: false,
                                            status: 404,
                                            message: "Customer not found"
                                        })
                                    }
                                    else {
                                        customerData.status = req.body.status

                                        customerData.save()
                                            .then((updatedCustomer) => {
                                                res.send({
                                                    success: true,
                                                    status: 200,
                                                    message: "Status Updated",
                                                    data: updatedCustomer
                                                })
                                            })
                                            .catch((err) => {
                                                res.send({
                                                    success: false,
                                                    status: 500,
                                                    message: err.message
                                                })
                                            })
                                    }
                                })
                                .catch((err) => {
                                    res.send({
                                        success: false,
                                        status: 500,
                                        message: err.message
                                    })
                                })
                        })
                        .catch((err) => {
                            res.send({
                                success: false,
                                status: 500,
                                message: err.message
                            })
                        })
                }
            })
            .catch((err) => {
                res.send({
                    success: false,
                    status: 500,
                    message: err.message
                })
            })



    }


}




module.exports = { add, all, single, update, changeStatus } 
