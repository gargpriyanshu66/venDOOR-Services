const customerModel=require('../customer/customerModel')
const categoryModel=require('../category/categoryModel')
const serviceProviderModel=require('../serviceProvider/serviceProviderModel')
const  bookingModel=require('../booking/bookingModel')
const serviceModel=require('../service/serviceModel')
const reviewModel=require('../review/reviewModel')

const getDashboard = async(req,res)=>{

    let totalCustomer = await customerModel.countDocuments({status:true})
    let totalCategory = await categoryModel.countDocuments({status:true})
    let totalServiceProvider = await serviceProviderModel.countDocuments({status:true})
    let totalBooking = await bookingModel.countDocuments()
    let totalReview = await reviewModel.countDocuments()
    let totalService = await serviceModel.countDocuments({status:true})

    res.send({
        success:true,
        status:200,
        message:"Dashboard",
        data:{
            totalCustomer:totalCustomer,
            totalCategory:totalCategory,
            totalServiceProvider:totalServiceProvider,
            totalBooking:totalBooking,
            totalReview:totalReview,
            totalService:totalService,
        }

    })

}

module.exports = {getDashboard}
