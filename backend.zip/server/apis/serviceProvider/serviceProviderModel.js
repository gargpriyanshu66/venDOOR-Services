const mongoose = require('mongoose')

const serviceProviderSchema = new mongoose.Schema({
    autoId: { type: Number, default: 0 },
    name: { type: String, default: '' },
    email: { type: String, default: '' },
    contact: { type: String, default: '' },
    address: { type: String, default: '' },
    description: { type: String, default: '' },
    businessContact: { type: String, default: '' },
    businessEmail: { type: String, default: '' },
    experience: { type: String, default: '' },
    image: { type: String, default: '' },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'user' ,default:null },
    createdAt: { type: Date, default: Date.now() },
    status: { type: Boolean, default: false }
})

module.exports = mongoose.model('serviceProvider', serviceProviderSchema)