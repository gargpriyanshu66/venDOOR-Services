
const { uploadImg } = require('../../utilities/helper')
const serviceProviderModel = require('../serviceProvider/serviceProviderModel')
const userModel = require('../user/userModel')
const bcrypt = require('bcrypt')

// const add = async (req, res) => {
    

//     let validation = ""

//     if (!req.body.name) {
//         validation += "Name is required "

//     }
//     if (!req.body.email) {
//         validation += "email is required "

//     }
//     if (!req.body.password) {
//         validation += "password is required "

//     }

//     if (!req.body.contact) {
//         validation += "contact is required "

//     }

//     if (!req.body.address) {
//         validation += "addess is required "

//     }
//     if (!req.body.description) {
//         validation += "description is required "

//     }

//     if (!req.body.businessContact) {
//         validation += "businessContact is required "

//     }

//     if (!req.body.businessEmail) {
//         validation += "businessEmail is required "

//     }

//     if (!req.body.experience) {
//         validation += "experience is required "

//     }
//     if (!req.file) {
//         validation += "image is required "

//     }



//     if (!!validation) {
//         res.send({
//             success: false,
//             status: 422,
//             message: "Validation Error : " + validation
//         })

//     }
//     else {

//         let olduser = await userModel.findOne({ email: req.body.email })

//         if (olduser == null) {
//             let userTotal = await userModel.countDocuments()
//             let userObj = new userModel()
//             userObj.autoId= userTotal + 1
//             userObj.name= req.body.name
//             userObj.email= req.body.email
//             userObj.password=bcrypt.hashSync(req.body.password, 10)
//             userObj.userType=2
//             userObj.status=false

//             userObj.save()
//                 .then(async (savedUser) => {
//                     let serviceProviderTotal = await serviceProviderModel.countDocuments()
//                      let imgUrl = "Image not uploaded";
//                             try {
//                                 imgUrl = await uploadImg(req.file.buffer);
//                             } catch (err) {
//                                 console.error("Cloudinary upload error:", err);
//                                 return res.status(500).json({
//                                     success: false,
//                                     message: "Image upload failed: " + err.message
//                                 });
//                             }
//                     let serviceProviderObj = new serviceProviderModel({
//                         autoId: serviceProviderTotal + 1,
//                         name: req.body.name,
//                         email: req.body.email,
//                         contact: req.body.contact,
//                         address: req.body.address,
//                         description: req.body.description,
//                         businessContact: req.body.businessContact,
//                         businessEmail: req.body.businessEmail,
//                         experience: req.body.experience,
//                         status: false,
//                         userId: savedUser._id,
//                         image : imgUrl
                        
                        

//                     })
//                     serviceProviderObj.save()

//                         .then((savedServiceProvider) => {
//                             savedUser.serviceProviderId = savedServiceProvider._id
//                             savedUser.save()
//                                 .then((result) => {

//                                     res.send({

//                                         success: true,
//                                         status: 200,
//                                         message: "New Service Provider added",
//                                         data: result
//                                     })
//                                 })


//                         })
//                         .catch((err) => {

//                             res.send({
//                                 success: false,
//                                 status: 500,
//                                 message: err.message,

//                             })
//                         })

//                 })
//                 .catch((err) => {
//                     res.send({
//                         success: false,
//                         status: 500,
//                         message: err.message
//                     })


//                 })
//         }

//         else {
//             res.send({
//                 success: false,
//                 status: 409,
//                 message: "Service Provider already exists"
//             })

//         }

//     }
// }
const add = async (req, res) => {
    let validation = "";

    if (!req.body.name) validation += "Name is required. ";
    if (!req.body.email) validation += "Email is required. ";
    if (!req.body.password) validation += "Password is required. ";
    if (!req.body.contact) validation += "Contact is required. ";
    if (!req.body.address) validation += "Address is required. ";
    if (!req.body.description) validation += "Description is required. ";
    if (!req.body.businessContact) validation += "Business Contact is required. ";
    if (!req.body.businessEmail) validation += "Business Email is required. ";
    if (!req.body.experience) validation += "Experience is required. ";
    if (!req.file) validation += "Image is required. ";

    if (validation) {
        return res.status(422).json({
            success: false,
            message: "Validation Error: " + validation.trim()
        });
    }

    try {
        const oldUser = await userModel.findOne({ email: req.body.email });
        if (oldUser) {
            return res.status(409).json({
                success: false,
                message: "Service Provider already exists"
            });
        }

        const userTotal = await userModel.countDocuments();

        // Create and save new user
        const newUser = new userModel({
            autoId: userTotal + 1,
            name: req.body.name,
            email: req.body.email,
            password: bcrypt.hashSync(req.body.password, 10),
            userType: 2, // Assuming 2 means service provider
            status: false
        });

        const savedUser = await newUser.save();

        // Upload image
        let imgUrl = "Image not uploaded";
        try {
            imgUrl = await uploadImg(req.file.buffer);
        } catch (err) {
            console.error("Cloudinary upload error:", err);
            return res.status(500).json({
                success: false,
                message: "Image upload failed: " + err.message
            });
        }

        const serviceProviderTotal = await serviceProviderModel.countDocuments();

        // Create and save new service provider
        const serviceProvider = new serviceProviderModel({
            autoId: serviceProviderTotal + 1,
            name: req.body.name,
            email: req.body.email,
            contact: req.body.contact,
            address: req.body.address,
            description: req.body.description,
            businessContact: req.body.businessContact,
            businessEmail: req.body.businessEmail,
            experience: req.body.experience,
            status: false,
            userId: savedUser._id,
            image: imgUrl
        });

        const savedServiceProvider = await serviceProvider.save();

        // Update user with serviceProviderId
        savedUser.serviceProviderId = savedServiceProvider._id;
        const finalUser = await savedUser.save();

        return res.status(200).json({
            success: true,
            message: "New Service Provider added",
            data: finalUser
        });

    } catch (err) {
        console.error("Server Error:", err);
        return res.status(500).json({
            success: false,
            message: "Server Error: " + err.message
        });
    }
};

const all = (req, res) => {

    serviceProviderModel.find(req.body)
        .populate('userId')
        .sort({ createdAt: -1 })
        .exec()

        .then((result) => {
            res.send({
                success: true,
                status: 200,
                message: "all documents loaded",
                total: result.length,
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })
}


const single = (req, res) => {

    serviceProviderModel.findOne({ _id: req.body._id })
        .populate('userId')
        .exec()

        .then((result) => {

            if (result == null) {

                res.send({

                    sucess: false,
                    status: 422,
                    message: "Service Provider not found"

                })
            }

            res.send({
                success: true,
                status: 200,
                message: "single document loaded",
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })

}

const update = async (req, res) => {
    let validations = ""
    if (!req.body._id) {
        validations += "_id is required "
    }

    if (!!validations) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error : " + validations
        })
    }
    else {

        let prevUser = await userModel.findOne({
            $and: [
                { email: req.body.email },
                { serviceProviderId: { $ne: req.body._id } }
            ]
        })

        if (!!prevUser) {
            res.send({
                success: false,
                status: 409,
                message: "Email Already Exists"
            })

        }
        else {


            userModel.findOne({ serviceProviderId: req.body._id }).exec()
                .then((userData) => {
                    if (userData == null) {
                        res.send({
                            success: false,
                            status: 404,
                            message: "User Not Found"
                        })
                    }
                    else {
                        if (!!req.body.name) userData.name = req.body.name
                        if (!!req.body.email) userData.email = req.body.email

                        userData.save()

                            .then((updatedUser) => {
                                serviceProviderModel.findOne({ _id: req.body._id }).exec()
                                    .then(async(serviceProviderData) => {
                                        if (userData == null) {
                                            res.send({
                                                success: false,
                                                status: 404,
                                                message: "Service Provider not found"
                                            })
                                        }
                                        else {
                                            if (!!req.body.name) serviceProviderData.name = req.body.name
                                            if (!!req.body.email) serviceProviderData.email = req.body.email
                                            if (!!req.body.contact) serviceProviderData.contact = req.body.contact
                                            if (!!req.body.address) serviceProviderData.address = req.body.address
                                            if (!!req.body.description) serviceProviderData.description = req.body.description
                                            if (!!req.body.businessContact) serviceProviderData.businessContact = req.body.businessContact
                                            if (!!req.body.businessEmail) serviceProviderData.businessEmail = req.body.businessEmail
                                            if (!!req.body.experience) serviceProviderData.experience = req.body.experience
                                            if(!!req.file){
                                                 let imgUrl = "Image not uploaded";
                                                        try {
                                                            imgUrl = await uploadImg(req.file.buffer);
                                                        } catch (err) {
                                                            console.error("Cloudinary upload error:", err);
                                                            return res.status(500).json({
                                                                success: false,
                                                                message: "Image upload failed: " + err.message
                                                            });
                                                        }
                                                serviceProviderData.image = imgUrl
                                                
                                            }
                                           



                                            serviceProviderData.save()

                                                .then((updatedServiceProvider) => {
                                                    res.send({
                                                        success: true,
                                                        status: 200,
                                                        message: "Service Provider Data Updated",
                                                        data: updatedServiceProvider
                                                    })
                                                })
                                                .catch((err) => {
                                                    res.send({
                                                        success: false,
                                                        status: 500,
                                                        message: err.message
                                                    })
                                                })
                                        }
                                    })
                                    .catch((err) => {
                                        res.send({
                                            success: false,
                                            status: 500,
                                            message: err.message


                                        })
                                    })
                            })
                            .catch((err) => {
                                res.send({
                                    success: false,
                                    status: 500,
                                    message: err.message
                                })
                            })
                    }
                })
                .catch((err) => {
                    res.send({
                        success: false,
                        status: 500,
                        message: err.message
                    })
                })

        }
    }


}

const changeStatus = async (req, res) => {
    let validations = ""
    if (!req.body._id) {
        validations += "_id is required "
    }
    if (!req.body.status) {
        validations += "status is required "
    }

    if (!!validations) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error : " + validations
        })
    }
    else {

        userModel.findOne({ serviceProviderId: req.body._id }).exec()
            .then((userData) => {
                if (userData == null) {
                    res.send({
                        success: false,
                        status: 404,
                        message: "User Not Found"
                    })
                }
                else {
                    userData.status = req.body.status


                    userData.save()
                        .then((updatedUser) => {
                            serviceProviderModel.findOne({ _id: req.body._id }).exec()
                                .then((serviceProviderData) => {
                                    if (serviceProviderData == null) {
                                        res.send({
                                            success: false,
                                            status: 404,
                                            message: "Customer not found"
                                        })
                                    }
                                    else {
                                        serviceProviderData.status = req.body.status

                                        serviceProviderData.save()
                                            .then((updatedServiceProvider) => {
                                                res.send({
                                                    success: true,
                                                    status: 200,
                                                    message: "Status Updated",
                                                    data: updatedServiceProvider
                                                })
                                            })
                                            .catch((err) => {
                                                res.send({
                                                    success: false,
                                                    status: 500,
                                                    message: err.message
                                                })
                                            })
                                    }
                                })
                                .catch((err) => {
                                    res.send({
                                        success: false,
                                        status: 500,
                                        message: err.message
                                    })
                                })
                        })
                        .catch((err) => {
                            res.send({
                                success: false,
                                status: 500,
                                message: err.message
                            })
                        })
                }
            })
            .catch((err) => {
                res.send({
                    success: false,
                    status: 500,
                    message: err.message
                })
            })



    }


}



module.exports = { add, all, single, update, changeStatus }

