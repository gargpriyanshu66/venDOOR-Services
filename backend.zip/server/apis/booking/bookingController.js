const Razorpay = require('razorpay')
const bookingModel = require('./bookingModel')


const add = async (req, res) => {
    // console.log(req.body)
    let validation = ""

    if (!req.body.customerName) {
        validation += "customerName is required"

    }
    if (!req.body.customerId) {
        validation += "customerId is required"

    }
    if (!req.body.contact) {
        validation += "contact is required"

    }
    if (!req.body.address) {
        validation += "address is required"

    }
    if (!req.body.serviceId) {
        validation += "serviceId is required"

    }
    if (!req.body.categoryId) {
        validation += "categoryId is required"

    }
    if (!req.body.providerId) {
        validation += "providerId is required"

    }
    if (!req.body.time) {
        validation += "time is required"

    }
    if (!req.body.date) {
        validation += "date is required"

    }


    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error : " + validation
        })

    }
    else {

        let total = await bookingModel.countDocuments()
        let booking = new bookingModel({

            autoId: total + 1,
            customerId: req.body.customerId,
            customerName: req.body.customerName,
            contact: req.body.contact,
            address: req.body.address,
            serviceId: req.body.serviceId,
            categoryId: req.body.categoryId,
            totalAmount: req.body.totalAmount,
            service: req.body.service,
            providerId: req.body.providerId,
            time: req.body.time,
            date: req.body.date
        })
        booking.save()
            .then(async (result) => {
                let _id = result._id
                const r = await bookingModel.findById(_id);

                if (!r) {
                    return res.status(404).json({
                        success: false,
                        message: "Request not found."
                    });
                }

                // Razorpay order creation
                const razorpay = new Razorpay({
                    key_id: 'rzp_test_RiJZ0zWB0h8XZ9',
                    key_secret: 'rYD34HzEL9rHAoC2BcjeLvnG',
                });

                const options = {
                    amount: req.body.totalAmount * 100, // Razorpay expects amount in paise
                    currency: "INR",
                    receipt: "receipt_order_" + new Date().getTime(),
                };

                const order = await razorpay.orders.create(options);

                r.paymentType = "online";
                r.paymentStatus = "paid";
                await r.save();

                res.status(200).json({
                    success: true,
                    message: "Razorpay order created",
                    order,
                    totalAmount: req.body.totalAmount,
                    data: result,
                    orderData : order
                });

                // res.send({
                //     success: true,
                //     status: 200,
                //     message: "New booking added",
                //     data: result
                // })
            })
            .catch((err) => {

                res.send({
                    success: false,
                    status: 500,
                    resp: "THis msg occurs",
                    message: err.message,

                })
            })
    }
}

const all = (req, res) => {

    bookingModel.find(req.body)
        .populate('customerId')
        .populate('serviceId')
        .populate('categoryId')
        .populate('providerId')
        .sort({ createdAt: -1 })
        .exec()

        .then((result) => {
            res.send({
                success: true,
                status: 200,
                message: "all documents loaded",
                total: result.length,
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })
}

const single = (req, res) => {

    bookingModel.findOne({ _id: req.body._id })
        .populate('customerId')
        .populate('serviceId')
        .populate('categoryId')
        .populate('providerId')
        .exec()

        .then((result) => {

            if (result == null) {

                res.send({

                    sucess: false,
                    status: 422,
                    message: "booking not found"

                })
            }

            res.send({
                success: true,
                status: 200,
                message: "single document loaded",
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })

}

const changeStatus = async (req, res) => {
    let validations = ""
    if (!req.body._id) {
        validations += "_id is required "
    }
    if (!req.body.status) {
        validations += "status is required "
    }

    if (!!validations) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error : " + validations
        })
    }
    else {

        bookingModel.findOne({ _id: req.body._id }).exec()
            .then((userData) => {
                if (userData == null) {
                    res.send({
                        success: false,
                        status: 404,
                        message: "Booking Not Found"
                    })
                }
                else {
                    userData.status = req.body.status
                    if (req.body.message) {
                        userData.message = req.body.message
                    }

                    userData.save()
                        .then((updatedUser) => {
                            res.send({
                                success: true,
                                status: 200,
                                message: "Status updated"

                            })
                        })
                        .catch((err) => {
                            res.send({
                                success: false,
                                status: 500,
                                message: err.message
                            })
                        })
                }
            })
            .catch((err) => {
                res.send({
                    success: false,
                    status: 500,
                    message: err.message
                })
            })



    }


}

module.exports = { add, all, single, changeStatus }