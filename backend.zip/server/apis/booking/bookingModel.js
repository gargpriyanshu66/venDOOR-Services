const mongoose = require('mongoose')

const bookingSchema = new mongoose.Schema({
    autoId: { type: Number, default: 0 },
    customerId: { type:mongoose.Schema.Types.ObjectId,ref:'customer',default:null},
    customerName: { type: String, default: '' },
    contact: { type: String, default: '' },
    address: { type: String, default: '' },
    serviceId: { type:mongoose.Schema.Types.ObjectId,ref:'service',default:null },
    categoryId: {  type:mongoose.Schema.Types.ObjectId,ref:'category',default:null },
    providerId: {type:mongoose.Schema.Types.ObjectId,ref:'serviceProvider',default:null },
    time: { type: String, default: '' },
    date: { type: Date, default: null },
    createdAt: { type: Date, default: Date.now() },
    message:{type:Date ,default:""},
    status: {type: String, default:"Pending"},
    paymentType: {type: String, default:""},
    paymentStatus: {type: String, default:""},
    totalAmount: { type: Number, default: 0 },
})

module.exports = mongoose.model('booking', bookingSchema)