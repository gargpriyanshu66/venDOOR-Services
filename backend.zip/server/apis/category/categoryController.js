
const { uploadImg } = require('../../utilities/helper');
const categoryModel = require('./categoryModel');

const add = async (req, res) => {
    let validation = "";

    if (!req.body.name) validation += "Name is required. ";
    if (!req.body.description) validation += "Description is required. ";
    if (!req.file) validation += "Image is required. ";

    if (validation) {
        return res.status(422).json({
            success: false,
            message: "Validation Error: " + validation.trim()
        });
    }

    try {
        const oldCategory = await categoryModel.findOne({ name: req.body.name });
        if (oldCategory) {
            return res.status(409).json({
                success: false,
                message: "Category already exists"
            });
        }

        const total = await categoryModel.countDocuments();

        let imgUrl = "Image not uploaded";
        try {
            imgUrl = await uploadImg(req.file.buffer);
        } catch (err) {
            console.error("Cloudinary upload error:", err);
            return res.status(500).json({
                success: false,
                message: "Image upload failed: " + err.message
            });
        }

        const category = new categoryModel({
            autoId: total + 1,
            name: req.body.name,
            description: req.body.description,
            image: imgUrl
        });

        const result = await category.save();

        return res.status(200).json({
            success: true,
            message: "New category added",
            data: result
        });

    } catch (err) {
        return res.status(500).json({
            success: false,
            message: "Server Error: " + err.message
        });
    }
};



const all = (req, res) => {

    req.body.status = true
    categoryModel.find(req.body)
    .sort({createdAt:-1})
    .exec()

        .then((result) => {
            res.send({
                success: true,
                status: 200,
                message: "all documents loaded",
                total: result.length,
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })
}


const single = (req, res) => {

    categoryModel.findOne({ _id: req.body._id }).exec()

        .then((result) => {

            if (result == null) {

                res.send({

                    sucess: false,
                    status: 422,
                    message: "Category not found"

                })
            }

            res.send({
                success: true,
                status: 200,
                message: "single document loaded",
                data: result

            })

        })
        .catch((err) => {

            res.send({
                success: false,
                status: 500,
                message: err.message
            })
        })

}


const update = (req, res) => {

    let validation = ""
    if (!req.body._id) {
        validation += "_id is required"
    }

    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error: " + validation
        })
    }

    else {

        categoryModel.findOne({ _id: req.body._id }).exec()

            .then(async(categoryData) => {

                if (categoryData == null) {

                    res.send(res.send({
                        success: false,
                        status: 404,
                        message: "Category not found"
                    })

                    )
                }

                else {

                    if (!!req.body.name) categoryData.name = req.body.name
                    if (!!req.body.description) categoryData.description = req.body.description
                    if(!!req.file){
                        // categoryData.image ='categoryImage/'+req.file.filename
                          let imgUrl = "Image not uploaded";
                                try {
                                    imgUrl = await uploadImg(req.file.buffer);
                                } catch (err) {
                                    console.error("Cloudinary upload error:", err);
                                    return res.status(500).json({
                                        success: false,
                                        message: "Image upload failed: " + err.message
                                    });
                                }

                    }
                    categoryData.save()
                        .then((result) => {

                            res.send({
                                success: true,
                                status: 200,
                                message: "Document updated",
                                data: result
                            })
                        })
                        .catch((err) => {

                            res.send({

                                success: false,
                                status: 500,
                                message: err.message
                            })

                        })
                }

            })
            .catch((err) => {

                res.send({
                    success: false,
                    status: 500,
                    message: err.message

                })
            })
    }
}

// hard delete
const deletefun = (req, res) => {
    let validation = "";
    if (!req.body._id) {
        validation += "_id is required";
    }

    if (!!validation) {
        res.send({
            success: false,
            status: 422,
            message: "Validation Error: " + validation
        });
    } else {
        categoryModel.findOneAndDelete({ _id: req.body._id })
            .then((deletedCategory) => {
                if (deletedCategory == null) {
                    res.send({
                        success: false,
                        status: 404,
                        message: "Category not found"
                    });
                } else {
                    res.send({
                        success: true,
                        status: 200,
                        message: "Document deleted successfully",
                        data: deletedCategory
                    });
                }
            })
            .catch((err) => {
                res.send({
                    success: false,
                    status: 500,
                    message: err.message
                });
            });
    }
};



// Soft delete
// const deletefun = (req, res) => {

//     let validation = ""
//     if (!req.body._id) {
//         validation += "_id is required"
//     }

//     if (!!validation) {
//         res.send({
//             success: false,
//             status: 422,
//             message: "Validation Error: " + validation
//         })
//     }

//     else {

//         categoryModel.findOne({ _id: req.body._id }).exec()

//             .then((categoryData) => {

//                 if (categoryData == null) {

//                     res.send(res.send({
//                         success: false,
//                         status: 404,
//                         message: "Category not found"
//                     })

//                     )
//                 }

//                 else {

//                     categoryData.status = false

//                     categoryData.save()
//                         .then((result) => {

//                             res.send({
//                                 success: true,
//                                 status: 200,
//                                 message: "Document delted",
//                                 data:result            

//                             })
//                         })
//                         .catch((err) => {

//                             res.send({

//                                 success: false,
//                                 status: 500,
//                                 message: err.message
//                             })

//                         })
//                 }

//             })
//             .catch((err) => {

//                 res.send({
//                     success: false,
//                     status: 500,
//                     message: err.message

//                 })
//             })
//     }



// }


module.exports = { add, all, single, update, deletefun }