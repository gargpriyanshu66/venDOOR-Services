
const express = require('express')
const router = express.Router()
const multer = require('multer')
const storage = multer.memoryStorage()
const upload = multer({ storage: storage })

const serviceController = require('../apis/service/serviceController')
const bookingController = require('../apis/booking/bookingController')
const reviewController = require('../apis/review/reviewController')
const serviceProviderController = require('../apis/serviceProvider/serviceProviderController')
const customerController = require('../apis/customer/customerController')
const userController = require('../apis/user/userController')
const categoryController = require('../apis/category/categoryController')


//Service Provider Image**************************************************
const serviceProviderStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './server/public/serviceProviderImage')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const newName = file.fieldname + '-' + uniqueSuffix + '-' + file.originalname
    cb(null, newName)
  }
})

const serviceProviderUpload = multer({ storage: serviceProviderStorage })
//Service Provider Image**************************************************


//Service Provider Image Update*******************************************
const serviceProviderUploadStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './server/public/serviceProviderImage')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const newName = file.fieldname + '-' + uniqueSuffix + '-' + file.originalname
    cb(null, newName)

  }
})
const serviceProviderUpdate = multer({ storage: serviceProviderUploadStorage })
// Service Provider Image Update*******************************************



//Service Image*********************************************************
const serviceStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './server/public/serviceImage')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const newName = file.fieldname + '-' + uniqueSuffix + '-' + file.originalname
    cb(null, newName)

  }
})
const serviceUpload = multer({ storage: serviceStorage })
//Service Image*********************************************************

//Service  Image Update************************************************
const serviceUploadStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './server/public/serviceImage')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const newName = file.fieldname + '-' + uniqueSuffix + '-' + file.originalname
    cb(null, newName)

  }
})
const serviceUpdate = multer({ storage: serviceUploadStorage })
// Service   Image Update*******************************************




//Login*************************************************
router.post('/login', userController.login)
//Login*************************************************

//Service***********************************************
router.post('/service/all', serviceController.all)
router.post('/service/single', serviceController.single)
//Service**********************************************

// Review***********************************************
router.post('/review/all', reviewController.all)
router.post('/review/single', reviewController.single)
// Review***********************************************

//Service Provider**************************************
router.post('/serviceProvider/add', upload.single('image'), serviceProviderController.add)
router.post('/serviceProvider/single', serviceProviderController.single)
router.post('/serviceProvider/all', serviceProviderController.all)
//Service Provider***************************************

// Category***********************************************
router.post('/category/all', categoryController.all)
router.post('/category/single', categoryController.single)
// Category***********************************************



// ===================Middleware-Tokencheker================
router.use(require('../middleware/tokenChecker'))
// ===================Middleware-Tokencheker================



//Change Status********************************************
router.post('/booking/changeStatus', bookingController.changeStatus)
//Change Status********************************************

// Change Password****************************************
router.post('/changePassword', userController.changePassword)
// Change Password****************************************

// Service************************************************
router.post('/service/add', upload.single('image'), serviceController.add)
router.post('/service/update', upload.single('image'), serviceController.update)
router.post('/service/delete', serviceController.deletefun)
// Services************************************************

// Booking*************************************************
router.post('/booking/all', bookingController.all)
router.post('/booking/single', bookingController.single)
// Booking**************************************************

// Service Provider*****************************************
router.post('/serviceProvider/update', upload.single('image'), serviceProviderController.update)
// Service Provider*****************************************


// Customer*************************************************
router.post('/customer/all', customerController.all)
router.post('/customer/single', customerController.single)
// Customer**************************************************


router.all("**", (req, res) => {
  res.send({
    success: false,
    status: 404,
    message: "Invalid "
  })
})

module.exports = router