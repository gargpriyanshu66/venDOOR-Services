
const express = require('express')
const router = express.Router()
const multer = require('multer')

const categoryController = require('../apis/category/categoryController')
const bookingController = require('../apis/booking/bookingController')
const reviewController = require('../apis/review/reviewController')
const serviceProviderController = require('../apis/serviceProvider/serviceProviderController')
const customerController = require('../apis/customer/customerController')
const serviceController = require('../apis/service/serviceController')
const dashboardController = require('../apis/dashboard/dashboardController')
const userController = require('../apis/user/userController')
const storage = multer.memoryStorage()
const upload = multer({ storage: storage })

//Category Image**************************************************
const categoryStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './server/public/categoryImage')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const newName = file.fieldname + '-' + uniqueSuffix + '-' + file.originalname
    cb(null, newName)

  }
})
const categoryUpload = multer({ storage: categoryStorage })
// Category Image**************************************************


//Category Image Update*******************************************
 const categoryUploadStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './server/public/categoryImage')
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    const newName = file.fieldname+'-'+uniqueSuffix+'-'+file.originalname
    cb(null, newName )

  }
})
const categoryUpdateUpload = multer({ storage: categoryUploadStorage })
// Category Image Update*******************************************


// Login**************************************************
router.post('/login', userController.login)
// Login**************************************************   


// ===================Middleware-Tokencheker================
router.use(require('../middleware/tokenChecker'))
// ===================Middleware-Tokencheker================


//Dashboard**********************************************
router.post('/dashboard', dashboardController.getDashboard)
//Dashboard**********************************************

// Change Password*****************************************
router.post('/changePassword', userController.changePassword)
// Change Password*****************************************   

//Change Status********************************************
router.post('/customer/changeStatus', customerController.changeStatus)
router.post('/serviceProvider/changeStatus', serviceProviderController.changeStatus)
router.post('/booking/changeStatus', bookingController.changeStatus)
//Change Status********************************************

//Add Category*********************************************
router.post('/category/add', upload.single('image'), categoryController.add)
router.post('/category/all', categoryController.all)
router.post('/category/single', categoryController.single)
router.post('/category/update', upload.single('image'), categoryController.update)
router.post('/category/delete', categoryController.deletefun)
//Add Category*********************************************    


// Booking************************************
router.post('/booking/all', bookingController.all)
router.post('/booking/single', bookingController.single)
// Booking*************************************


// Review**************************************
router.post('/review/all', reviewController.all)
router.post('/review/single', reviewController.single)
router.post('/review/delete', reviewController.deletefun)
// Review**************************************


// service Provider*****************************
router.post('/serviceProvider/all', serviceProviderController.all)
router.post('/serviceProvider/single', serviceProviderController.single)
//service Provider******************************


// Customer************************************
router.post('/customer/all', customerController.all)
router.post('/customer/single', customerController.single)
//Customer*************************************


//service**************************************
router.post('/service/all', serviceController.all)
router.post('/service/single', serviceController.single)
//services************************************




router.all("**", (req, res) => {
  res.send({
    success: false,
    status: 404,
    message: "Invalid "
  })
})

module.exports = router