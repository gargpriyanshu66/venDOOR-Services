
const express = require('express')
const router = express.Router()



const bookingController = require('../apis/booking/bookingController')
const categoryController = require('../apis/category/categoryController')
const reviewController = require('../apis/review/reviewController')
const serviceProviderController = require('../apis/serviceProvider/serviceProviderController')
const customerController = require('../apis/customer/customerController')
const serviceController = require('../apis/service/serviceController')
const userController = require('../apis/user/userController')



// Login**************************************************
router.post('/login', userController.login)
// Login**************************************************

// Category***********************************************
router.post('/category/all', categoryController.all)
router.post('/category/single', categoryController.single)
// Category***********************************************

// Review*************************************************
router.post('/review/add', reviewController.add)
router.post('/review/all', reviewController.all)
router.post('/review/single', reviewController.single)
// Review**************************************************

// Service Provider****************************************
router.post('/serviceProvider/all', serviceProviderController.all)
router.post('/serviceProvider/single', serviceProviderController.single)
// Service Provider****************************************

// Service**************************************************
router.post('/service/all', serviceController.all)
router.post('/service/single', serviceController.single)
// Services*************************************************

// Add Customer*********************************************
router.post('/customer/add', customerController.add)
// Add Customer*********************************************




// ===================Middleware-Tokencheker================
router.use(require('../middleware/tokenChecker'))
// ===================Middleware-Tokencheker================




// Change Password*****************************************
router.post('/changePassword', userController.changePassword)
// Change Password******************************************

// Booking**************************************************
router.post('/booking/add', bookingController.add)
router.post('/booking/single', bookingController.single)
router.post('/booking/all', bookingController.all)
// Booking**************************************************

// Customer**************************************************
router.post('/customer/single', customerController.single)
router.post('/customer/update', customerController.update)
// Customer**************************************************   



router.all("**", (req, res) => {
    res.send({
        success: false,
        status: 404,
        message: "Invalid "
    })
})

module.exports = router