const mongoose = require('mongoose')
// mongoose.connect("mongodb://127.0.0.1:27017/workwise")
mongoose.connect("mongodb+srv://priyanshugarg6602:KnG4xoZGDNFL8u0G@cluster0.ocizwmr.mongodb.net/workwise")
   .then(() => {
      console.log("DB connect");

   })
   .catch((err) => {
      console.log("error in connection", err);

   })