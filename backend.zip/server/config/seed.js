const userModel = require("../apis/user/userModel");
const bcrypt = require('bcrypt')

userModel.findOne({ email: "admin@gmail.com" }).exec()
    .then((data) => {

        if (data == null) {

            let admin = new userModel({
                autoId: 1,
                name: "Admin",
                email: "admin@gmail.com",
                password: bcrypt.hashSync("123", 10),
                userType: 1
            })

            admin.save()
                .then((data) => {
                    console.log("Admin created");

                })

                .catch((err) => {
                    console.log("error finding in admin", err);

                })

        }
        else {
            console.log("admin already exist");

        }
    })

    .catch((err) => {
        console.log("error finding in admin", err)
    })