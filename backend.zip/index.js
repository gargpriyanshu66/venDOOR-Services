const express = require('express')
const app = express()
const multer  = require('multer')
const PORT = 5000

const cors = require('cors')
app.use(cors())

const db = require('./server/config/db')
const seed = require('./server/config/seed')

app.use(express.static('server/public/'))

app.use(express.urlencoded({ extended: true }))
app.use(express.json())

const adminRoutes = require('./server/routes/adminRoutes')
app.use("/admin", adminRoutes)

const serviceProviderRoutes = require('./server/routes/serviceProviderRoutes')
app.use("/service", serviceProviderRoutes)

const customerRoutes = require('./server/routes/customerRoutes')
app.use("/customer", customerRoutes)



app.get('/', (req, res) => {

    res.send("welcome")
})

app.listen(PORT, (err) => {

    if (err) {
        console.log("error", err);

    }
    else {
        console.log("successfully");

    }

})
