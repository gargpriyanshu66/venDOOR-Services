import axios from "axios";

export const BaseURL = "http://localhost:5000/";
// export const BaseURL = "https://workwise-backend-live.vercel.app/";

class APIService {

    getToken() {
        let obj = {
            Authorization: sessionStorage.getItem('token')
        }
        return obj
    }

    AdminLogin(data) {

        return axios.post(BaseURL + "admin/login", data)
    }

    CustomerRegister(data) {

        return axios.post(BaseURL + "customer/customer/add", data)
    }

    ProviderRegister(data) {

        return axios.post(BaseURL + "service/serviceProvider/add", data)
    }

    AllServices(data) {

        return axios.post(BaseURL + "service/service/all",data)
    }
    AllCategry(data) {

        return axios.post(BaseURL + "admin/category/all", data, { headers: this.getToken() })
    }

    AddCategory(data) {

        return axios.post(BaseURL + "admin/category/add", data, { headers: this.getToken() })
    }


    AllProvider(data) {

        return axios.post(BaseURL + "admin/serviceProvider/all", data, { headers: this.getToken() })
    }

    SingleProvider({ _id: id }) {

        return axios.post(BaseURL + "admin/serviceProvider/all", { _id: id }, { headers: this.getToken() })
    }

    ProviderStatus(data) {

        return axios.post(BaseURL + "admin/serviceProvider/changeStatus", data, { headers: this.getToken() })
    }

    AllBooking(data) {

        return axios.post(BaseURL + "admin/booking/all", data, { headers: this.getToken() })
    }

    SingleCategory({ _id: id }) {

        return axios.post(BaseURL + "admin/category/single", { _id: id }, { headers: this.getToken() })
    }

    UpdateCategory(data) {

        return axios.post(BaseURL + "admin/category/update", data, { headers: this.getToken() })
    }

    DeleteCategory({ _id: id }) {

        return axios.post(BaseURL + "admin/category/delete", { _id: id }, { headers: this.getToken() })
    }

    AllCustomer(data) {

        return axios.post(BaseURL + "admin/customer/all", data, { headers: this.getToken() })
    }
   s(data) {

        return axios.post(BaseURL + "admin/review/all", data, { headers: this.getToken() })
    }
    DeleteReview({ _id: id }) {

        return axios.post(BaseURL + "admin/review/delete", { _id: id }, { headers: this.getToken() })
    }

    CustomerStatus(data) {

        return axios.post(BaseURL + "admin/customer/changeStatus", data, { headers: this.getToken() })
    }

    AddServices(data) {

        return axios.post(BaseURL + "service/service/add", { data }, { headers: this.getToken() })
    }

    AllCategryProvider(data) {

        return axios.post(BaseURL + "service/category/all", data)
    }

    AllServiceProvider(data) {

        return axios.post(BaseURL + "service/serviceProvider/all", data, { headers: this.getToken() })
    }

    AllServiceCutomer(data) {

        return axios.post(BaseURL + "customer/service/all",data)
    }

    AllServiceProviderCutomer(data) {

        return axios.post(BaseURL + "customer/serviceProvider/all")
    }

    AddReview(data) {

        return axios.post(BaseURL + "customer/review/add", data)
    }

    AllCategryCustomer(data) {

        return axios.post(BaseURL + "customer/category/all", data)
    }
    AllProviderCustomer(data) {

        return axios.post(BaseURL + "customer/serviceProvider/all", data)
    }

    AddBooking(data) {

        return axios.post(BaseURL + "customer/booking/add", data, { headers: this.getToken() })
    }


    SingleCustomer({ _id: id }) {

        return axios.post(BaseURL + "customer/customer/single", { _id: id }, { headers: this.getToken() })
    }

    UpdateCustomer(data) {

        return axios.post(BaseURL + "customer/customer/update", data, { headers: this.getToken() })
    }

    AddServiceProvider(data) {

        return axios.post(BaseURL + "service/service/add", data, { headers: this.getToken() })
    }
    UpdateServices(data){
    
        return axios.post(BaseURL+"service/service/update",data,{headers:this.getToken()})
    }

    SingleServices({ _id: id }){
    
        return axios.post(BaseURL+"service/service/single",{ _id: id },{headers:this.getToken()})
    }


    AllBookingProvider(data){
    
        return axios.post(BaseURL+"service/booking/all",data,{headers:this.getToken()})
    }

    UpdateBooking(data){
    
        return axios.post(BaseURL+"service/booking/all",data,{headers:this.getToken()})
    }

    SingleProviders({ _id: id }){
    
        return axios.post(BaseURL+"service/serviceProvider/single",{ _id: id },{headers:this.getToken()})
    }
    UpdateProvider(data){
    
        return axios.post(BaseURL+"service/serviceProvider/update",data,{headers:this.getToken()})
    }

    AllReviews(data){
    
        return axios.post(BaseURL+"admin/review/all",data,{headers:this.getToken()})
    }

    DeleteService({ _id: id }){
    
        return axios.post(BaseURL+"service/service/delete",{ _id: id },{headers:this.getToken()})
    }

    AllReviewsProvider(data){
    
        return axios.post(BaseURL+"service/review/all",data,{headers:this.getToken()})
    }

    SingleBooking({ _id: id }) {

        return axios.post(BaseURL + "customer/booking/single", { _id: id }, { headers: this.getToken() })
    }


    SingleCategoryCustomer({ _id: id }) {

        return axios.post(BaseURL + "customer/category/single", { _id: id })
    }


    Dashboard(data){
    
        return axios.post(BaseURL+"admin/dashboard",data,{headers:this.getToken()})
    }

    AllBookingcustomer(data) {

        return axios.post(BaseURL + "customer/booking/all",data, { headers: this.getToken() })
    }


    AllServiceAdmin(data) {

        return axios.post(BaseURL + "admin/service/all",data, { headers: this.getToken() })
    }

    AllBookingAdmin(data) {

        return axios.post(BaseURL + "admin/booking/all",data, { headers: this.getToken() })
    }

    ChangeStatusBooking(data) {

        return axios.post(BaseURL + "service/booking/changeStatus",data, { headers: this.getToken() })
    }

    }

export default new APIService