import { Link } from "react-router-dom";

export default function AdminFooter(){
    return(
      <>
      <>
 {/* Footer Start */}
 <div className="container-fluid footer py-5">
    <div className="container py-5">
      <div className="row g-5 justify-content-center">

        <div className="col-md-6 col-lg-6 col-xl-3">
          <div className="footer-item d-flex flex-column">
            <h4 className="mb-4 text-white">Get In Touch</h4>
            <a href="">
              <i className="fas fa-home me-2" />123 MG Road, New Delhi, India
            </a>
            <a href="">
              <i className="fas fa-envelope me-2" /> info@workwise.in
            </a>
            <a href="">
              <i className="fas fa-phone me-2" /> +91 98765 43210
            </a>
            <a href="" className="mb-3">
              <i className="fas fa-print me-2" /> +91 98765 43211
            </a>
            <div className="d-flex align-items-center">
              <i className="fas fa-share fa-2x text-white me-2" />
              <a
                className="btn-square btn btn-primary rounded-circle mx-1"
                href=""
              >
                <i className="fab fa-facebook-f" />
              </a>
              <a
                className="btn-square btn btn-primary rounded-circle mx-1"
                href=""
              >
                <i className="fab fa-twitter" />
              </a>
              <a
                className="btn-square btn btn-primary rounded-circle mx-1"
                href=""
              >
                <i className="fab fa-instagram" />
              </a>
              <a
                className="btn-square btn btn-primary rounded-circle mx-1"
                href=""
              >
                <i className="fab fa-linkedin-in" />
              </a>
            </div>
          </div>
        </div>

        <div className="col-md-6 col-lg-6 col-xl-3">
          <div className="footer-item d-flex flex-column">
          <h4 className="mb-4 text-white">Quick Links</h4>
                    <Link to={"/admin"}>
                      <i className="fas fa-angle-right me-2" /> Home
                    </Link>

                    <Link to={"/admin/addcategory"}>
                    <i className="fas fa-angle-right me-2" /> Add Category
                    </Link>

                    <Link to={"/admin/manage"}>
                      <i className="fas fa-angle-right me-2" /> Manage Category
                    </Link>

                    <Link to={"/admin/provider"}>
                      <i className="fas fa-angle-right me-2" /> Providers
                    </Link>

                    <Link to={"/admin/customer"}>
                      <i className="fas fa-angle-right me-2" /> Customers
                    </Link>

                    <Link to={"/admin/review"}>
                      <i className="fas fa-angle-right me-2" /> Reviews
                    </Link>

                    <Link to={"/admin/booking"}>
                      <i className="fas fa-angle-right me-2" /> Bookings
                    </Link>
          </div>
        </div>

        <div className="col-md-6 col-lg-6 col-xl-3">
          <div className="footer-item d-flex flex-column">
          <h4 className="mb-4 text-white">Social</h4>
                  <Link to={"https://www.instagram.com/"}>
                      <i className="fas fa-angle-right me-2" /> Instagram
                    </Link>

                    <Link to={"https://www.facebook.com/"}>
                      <i className="fas fa-angle-right me-2" /> Facebook
                    </Link>

                    <Link to={"https://www.x.com/"}>
                      <i className="fas fa-angle-right me-2" /> Twitter
                    </Link>
          </div>
        </div>
        
      </div>
    </div>
  </div>
  {/* Footer End */}

</>

      </>
    )
  }