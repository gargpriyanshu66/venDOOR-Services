import { Outlet } from "react-router-dom";
import Footer from "../customerLayout/Footer";
import Header from "../customerLayout/Header";


export default function CustomerMaster(){
    return(
        <>
        <Header></Header>
        <Outlet></Outlet>
       <Footer></Footer>

        </>
    )
}