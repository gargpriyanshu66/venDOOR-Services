import { Outlet } from "react-router-dom";
import ProviderHeader from "../serviceProviderLayout/ProviderHeader";
import Footer from "../customerLayout/Footer";

export default function ServiceProviderMaster() {
    return (
        <>
             <ProviderHeader></ProviderHeader>
            <Outlet></Outlet>
            <Footer></Footer>
             
            
        </>
    )
}