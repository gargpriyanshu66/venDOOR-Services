import { useEffect, useState } from "react";
import APIService from "../APIService";
import { useParams } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";

export default function ManageProfile() {
  var [image, setImage] = useState("");
  var [newImage, setNewImage] = useState("");
  var [ServiceProvider, setServiceProvider] = useState("")
  var [description, setDescription] = useState("");
  var [name, setName] = useState("");
  var [email, setEmail] = useState("");
  var [contact, setContact] = useState("");
  var [address, setAddrss] = useState("");
  var [bussinessContact, setBussinessContact] = useState("");
  var [bussinessEmail, setBussinessEmail] = useState("");
  var [experience, setExperience] = useState("");


  const _id = sessionStorage.getItem("ServiceProviderid")
  console.log("id is", _id);



  useEffect(() => {
    fetchSingleProvider()
  }, []);

  function fetchSingleProvider() {
    APIService.SingleProviders({ _id: _id })


      .then((res) => {
        console.log("data is", res.data);
        setName(res.data.data.name)
        setDescription(res.data.data.description)
        setEmail(res.data.data.email)
        setContact(res.data.data.contact)
        setImage(res.data.data?.image)
        setBussinessContact(res.data.data.businessContact)
        setBussinessEmail(res.data.data.businessEmail)
        setAddrss(res.data.data.address)
        setExperience(res.data.data.experience)


      })
      .catch((err) => {
        console.log(err);

      })
  }


  const handSubmit = (e) => {
    e.preventDefault();


    let data = new FormData()
    data.append("_id", _id)

    data.append("image", newImage)
    data.append("name", name)
    data.append("email", email)
    data.append("contact", contact)
    data.append("address", address)
    data.append("description", description)
    data.append("businessEmail", bussinessEmail)
    data.append("businessContact", bussinessContact)
    data.append("experience", experience)


    APIService.UpdateProvider(data)
      .then((res) => {
        console.log("skjja", ServiceProvider);
        if (res.data.success) {
          console.log("true", res.data.message);
          toast.success(res.data.message, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",

          })
          fetchSingleProvider()

        }
        else {
          toast.error(res.data.message)
        }


      })
      .catch((err) => {
        console.log(err);
        toast.error(" somthing went wrong")

      })

  }


  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid about1 ">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Manage Profile</h3>
          </div>
        </div>
        {/* Header End */}
      </>
      <div className="container-fluid ">
        <div className="container py-5">
          <div className="p-5  rounded">
            <div className="row g-4">
              <div className="offset-md-7 col-md-6 profile-form">
                <ToastContainer
                  position="top-right"
                  autoClose={5000}
                  hideProgressBar={false}
                  newestOnTop={false}
                  closeOnClick
                  rtl={false}
                  pauseOnFocusLoss
                  draggable
                  pauseOnHover
                  theme="dark"

                />

                <img src={ image} height={"100px"} className="pic"></img><div className="div"><h1 className="text-light">PROFILE</h1></div>
                <form onSubmit={handSubmit} className="profile-form" >
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Name  </label>
                    <input type="text" class="form-control" id="exampleInputPassword1" value={name} onChange={(e) => { setName(e.target.value) }} />
                  </div>

                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Email  </label>
                    <input type="text" class="form-control" id="exampleInputPassword1" value={email} onChange={(e) => { setEmail(e.target.value) }} />

                  </div>

                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label"> Description</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value={description} onChange={(e) => { setDescription(e.target.value) }} />

                  </div>
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Image  </label>
                    <input type="file" class="form-control" id="exampleInputPassword1" onChange={(e) => { setNewImage(e.target.files[0]) }} />
                  </div>

                  
                  <div class="mb-3">

                    <label for="exampleInputPassword1" class="form-label">Contact  </label>
                    <input type="text" class="form-control" id="exampleInputPassword1" value={contact} onChange={(e) => { setContact(e.target.value) }} />
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Address  </label>
                    <input type="text" class="form-control" id="exampleInputPassword1" value={address} onChange={(e) => { setAddrss(e.target.value) }} />
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label"> Bussiness contact </label>
                    <input type="text" class="form-control" id="exampleInputPassword1" value={bussinessContact} onChange={(e) => { setBussinessContact(e.target.value) }} />
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Bussiness Email  </label>
                    <input type="text" class="form-control" id="exampleInputPassword1" value={bussinessEmail} onChange={(e) => { setBussinessEmail(e.target.value) }} />
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Experience  </label>
                    <input type="text" class="form-control" id="exampleInputPassword1" value={experience} onChange={(e) => { setExperience(e.target.value) }} />
                  </div>





                  <button type="submit" class="btn btn-primary mt-5" >Update</button>

                </form>

              </div>
            </div>
          </div>
        </div>
      </div>

    </>
  )
}