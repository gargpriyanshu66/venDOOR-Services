import { useEffect, useState } from "react";
import APIService from "../APIService";
import { Link } from "react-router-dom";
import { ClipLoader } from "react-spinners";
import { toast } from "react-toastify";




export default function ManageService() {

  const _id = sessionStorage.getItem("ServiceProviderid")
  console.log("ids", _id);
  var [data, setData] = useState([])
  const [visible, setvisible] = useState(false)


  useEffect(() => {

    APIService.AllServices({ serviceProviderId: _id })

      .then((res) => {
        console.log("data is ", res.data.data);
        setData(res.data.data)
        setvisible(false)

      })
      .catch((err) => {
        console.log("error is", err);
        setvisible(false)

      })


  }, [])

  const handledelte = (id) => {

    APIService.DeleteService({ _id: id })
      .then((res) => {
        window.confirm("Are you want to  delete??")
        APIService.AllServices({ serviceProviderId: _id })
          .then((res) => {
            console.log(res.data);
            setData(res.data.data)
            setvisible(false)

          })
          .catch((err) => {
            console.log(err);
            setvisible(false)

          })


      })
      .catch((err) => {
        toast.error("Something went wrong!!")

      })
  }


  const style = {
    textAlign: 'center'
  }


  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid servicep">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Manage Service</h3>
          </div>
        </div>
        {/* Header End */}
      </>
      <div className="container-fluid" >


        {/* <ToastContainer /> */}

        <div className="row mt-5">
          <div className="col-md-2"></div>
          <div className="col-md-8">

            {visible ? (<ClipLoader size={100}></ClipLoader>) : (<table className="table table-bordered text-light" style={{ backgroundColor: '#121b51 ' }}>
              <thead>
                <tr>
                  <th className="ps-3">Sno</th>
                  <th className="ps-3">Service Name</th>
                  <th className="ps-3">Category</th>
                  <th className="ps-3">Image</th>
                  <th className="ps-3">Price</th>
                  <th className="ps-3">Description</th>
                  <th className="ps-5">Action</th>

                </tr>
              </thead>
              <tbody>
                {
                  data?.map((el, index) => (
                    <tr key={index}>
                      <td className="ps-3">{index + 1}</td>
                      <td className="ps-3">{el?.name}</td>
                      <td className="ps-3">{el?.categoryId?.name}</td>
                      <td className="ps-3"><img src={ el?.image} height={"100px"}></img></td>
                      <td className="ps-3">Rs. {el?.price}</td>
                      <td className="ps-3">{el?.description}</td>
                      <td className="ps-5"><Link to={"/provider/update/" + el?._id} className="btn btn-success mt-2" style={{ width: '71px', backgroundColor: 'green' }}>Edit</Link>
                        <button className="btn  mt-2" style={{ background: "red", width: "70px", color: "white" }} onClick={() => { handledelte(el?._id) }}>Delete</button>
                      </td>
                    </tr>
                  ))
                }
              </tbody>


            </table>)}
          </div>
        </div>
      </div>



    </>
  )
}