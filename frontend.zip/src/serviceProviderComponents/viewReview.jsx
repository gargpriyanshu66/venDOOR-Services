import { useEffect, useState } from "react";
import APIService from "../APIService";

export default function ViewReview() {
    var [data, setData] = useState([])
    var [category, setCategory] = useState([])
    // var [del, setdel] = useState(true)

    const _id = sessionStorage.getItem("ServiceProviderid")
    console.log("ids", _id);




    useEffect(() => {

        APIService.AllReviewsProvider({providerId:_id})

            .then((res) => {
                console.log("data is ", res.data.data);

                setData(res.data.data)


            })
            .catch((err) => {
                console.log("error is", err);


            })


    }, [])
    return (
        <>
            {/* Header Start */}
            <div className="container-fluid review">
                <div className="container text-center py-5" style={{ maxWidth: 900 }}>
                    <h3 className="text-white display-3 mb-4">Review</h3>
                </div>
            </div>
            {/* Header End */}



            <div className="container-fluid" >


                {/* <ToastContainer /> */}

                <div className="row mt-5">
                    <div className="col-md-2"></div>
                    <div className="col-md-8">
                        <table className="table text-light"  style={{ backgroundColor: '#808080' }}>
                            <tr>
                                <th className="ps-2 pt-3 text-light">Sno</th>
                                <th className="ps-5 pt-3 text-light"> Customer Name</th>
                                <th className="ps-5 pt-3 text-light"> Service Name</th>
                                <th className="ps-5 pt-3 text-light"> Provider Name</th>
                                <th className="ps-5 pt-3 text-light"> Review</th>
                                <th className="ps-5 pt-3 pe-2 text-light"> Rating</th>
                            </tr>
                            {

                                data.map((el, index) => (
                                    <tr>
                                        <td className="ps-5 pt-3 text-light">{index + 1}</td>
                                        <td className="ps-5 pt-3 text-light">{el.customerId?.name}</td>
                                        <td className="ps-5 pt-3 text-light">{el.serviceId?.name}</td>
                                        <td className="ps-5 pt-3 text-light">{el.providerId?.name}</td>
                                        <td className="ps-5 pt-3 text-light">{el.review}</td>
                                        <td className="ps-5 pt-3 text-light">{el.rating}</td>
                                        



                                    </tr>
                                ))


                            }


                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}