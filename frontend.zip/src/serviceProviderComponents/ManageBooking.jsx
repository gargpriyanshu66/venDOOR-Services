import { useEffect, useState } from "react"
import { toast, ToastContainer } from "react-toastify";
// import moment from 'moment';
import APIService from "../APIService";

export default function ManageBooking() {
  const [data, setdata] = useState([""])

  const id = sessionStorage.getItem("ServiceProviderid")

  useEffect(() => {


    APIService.AllBookingProvider({ providerId: id })


      .then((res) => {
        console.log("data is ", res);

        setdata(res.data.data)



      })
      .catch((err) => {
        console.log("error is", err);


      })


  }, [])

  const handledelete = (id) => {

    const Id = sessionStorage.getItem("ServiceProviderid")

    console.log("hsdjhdk", id);

    let data = {
      _id: id,
      status: "Approved"
    }
    APIService.ChangeStatusBooking(data)
      .then((res) => {
        console.log(res);
        // setdel(false)

        toast.success("Booking Approved!", {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",

        })

        APIService.AllBookingProvider({ providerId: Id })

          .then((res) => {
            console.log("data is ", res.data.data);

            setdata(res.data.data)
            // setdel(false)


          })
          .catch((err) => {
            console.log("error is", err);
            // setdel(false)

          })


      })
      .catch((err) => {
        console.log(err);
        // setdel(false)

      })
  }

  const handledelete2 = (id) => {
    const Id = sessionStorage.getItem("ServiceProviderid")

    console.log("hsdjhdk", id)
    let data = {
      _id: id,
      status: "Declined"
    }
    APIService.ChangeStatusBooking(data)
      .then((res) => {
        console.log(res);
        // setdel(false)
        toast.success("Booking Declined!", {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",

        })

        APIService.AllBookingProvider({ providerId: Id })

          .then((res) => {
            console.log("data is ", res.data.data);

            setdata(res.data.data)
            // setdel(false)


          })
          .catch((err) => {
            console.log("error is", err);
            // setdel(false)

          })


      })
      .catch((err) => {
        console.log(err);
        // setdel(false)

      })
  }

  const completedBooking = (id) => {
    const Id = sessionStorage.getItem("ServiceProviderid")

    console.log("hsdjhdk", id)
    let data = {
      _id: id,
      status: "Completed"
    }
    APIService.ChangeStatusBooking(data)
      .then((res) => {
        console.log(res);
        // setdel(false)
        toast.success("Booking Completed!", {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",

        })
        APIService.AllBookingProvider({ providerId: Id })

          .then((res) => {
            console.log("data is ", res.data.data);

            setdata(res.data.data)
            // setdel(false)


          })
          .catch((err) => {
            console.log("error is", err);
            // setdel(false)

          })


      })
      .catch((err) => {
        console.log(err);
        // setdel(false)

      })
  }
  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid booking">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Manage Booking</h3>
            <ToastContainer
              position="top-center"
              autoClose={5000}
              hideProgressBar={false}
              newestOnTop={false}
              closeOnClick
              rtl={false}
              pauseOnFocusLoss
              draggable
              pauseOnHover
              theme="dark"

            />
          </div>  
        </div>
        {/* Header End */}
      </>
      <div className="row mt-5 container">
        <div className="col-md-1"></div>
        <div className="col-md-10">
          <table className="table table-bordered" style={{ backgroundColor: '#808080' }}>
            <tr>
              <th className="ps-5 pt-3 text-light">Sno</th>
              <th className="ps-5 pt-3 text-light">Customer Name</th>
              <th className="ps-5 pt-3 text-light">service Name</th>
              <th className="ps-5 pt-3 text-light">Contact</th>
              <th className="ps-5 pt-3 text-light">Address</th>
              <th className="ps-5 pt-3 text-light">Time</th>
              <th className="ps-5 pt-3 text-light ">Date</th>
              <th className="ps-5 pt-3 text-light ">Status</th>
              <th className="ps-5 pt-3 text-light ">Action</th>

            </tr>
            {

              data.map((el, index) => (
                <tr>
                  <td className="ps-5 pt-3 text-light">{index + 1}</td>
                  <td className="ps-5 pt-3 text-light">{el.customerName}</td>
                  <td className="ps-5 pt-3 text-light">{el.serviceId?.name}</td>
                  <td className="ps-5 pt-3 text-light">{el.contact}</td>
                  <td className="ps-5 pt-3 text-light">{el.address}</td>
                  <td className="ps-5 pt-3 text-light">{el.time}</td>

                  {/* <td className="ps-5  pt-3 text-light">{moment(el.date).format('MM/DD/YYYY')}</td> */}
                  {/* <td className="ps-5  pt-3 text-light">{""}</td> */}
                  <td>
                     {new Date(el.date).toLocaleDateString("en-US", {
                                year: "numeric",
                                month: "2-digit",
                                day: "2-digit",
                              })}
                  </td>
                  <td className="ps-5  pt-3 text-light">{el.status}</td>
                  <td className="ps-5  pe-4 text-dark">

                    {el.status == "Pending" ? <><button className="btn text-light mb-2 mt-2" style={{ width: '71px', backgroundColor: "red" }} onClick={() => { handledelete(el._id) }} >Approve</button>
                      <button className="btn  text-light mt-2 mb-2" style={{ width: '71px', backgroundColor: "green" }} onClick={() => { handledelete2(el._id) }} >Decline</button></> : ""
                    }
                    {el?.status == "Pending" ? <></> : <>
                      {el.status == "Approved" ? <button className="btn text-light mb-3 mt-2" style={{ width: '85px', backgroundColor: "green" }} onClick={() => { completedBooking(el._id) }}>Complete</button> : ""}
                    </>}

                    {el.status == "Declined" ? <></> : <p className="pt-3 text-light">Completed</p>}

                      
                  </td>


                </tr>
              ))


            }


          </table>
        </div>
      </div>
      <div className="col-md-1"></div>

    </>
  )
}