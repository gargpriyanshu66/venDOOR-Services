import { toast, ToastContainer } from "react-toastify";
import { useEffect, useState } from "react";
import APIService from "../APIService";
import { useNavigate, useParams } from "react-router-dom";

export default function UpdateServices() {

  var [image, setImage] = useState("");
  var [serviceProvider, setServiceProvider] = useState("");
  var [serviceName, setServiceName] = useState("");
  var [services, setServices] = useState([]);
  var [services, setServices] = useState('');
  var [price, setPrice] = useState("")
  var [description, setDescription] = useState("");
  var [newImage, setNewImage] = useState([])
  var [category, setCategory] = useState([]);
  var [categoryProvider, setCategoryProvider] = useState([]);

  const nav = useNavigate()

  const param = useParams();
  const id = param.id;

  useEffect(() => {

    APIService.AllServices()
      .then((res) => {
        console.log("data is ", res.data.data);
        setServices(res.data.data);
      })
      .catch((err) => {
        console.log("error is", err);
      });


    APIService.AllCategryProvider()

      .then((res) => {
        console.log("data is", res.data.data);

        setCategory(res.data.data)

      })
      .catch((err) => {
        console.log(err);

      })


    APIService.SingleServices({ _id: id })
      .then((res) => {
        console.log("Single Service : ", res.data.data)
        setImage(res.data.data.image);
        setServiceProvider(res.data.data.serviceProviderId._id);
        setServiceName(res.data.data.name);
        setDescription(res.data.data.description);
        setPrice(res.data.data.price)
        setCategoryProvider(res.data.data.categoryId._id)
      })
      .catch((err) => {
        console.log(err);
      });
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();

    let data = new FormData();
    data.append("_id", id);
    // 
    data.append("image", newImage);
    data.append("description", description);
    data.append("serviceProviderId", serviceProvider);
    data.append("name", serviceName);
    data.append("price", price);


    APIService.UpdateServices(data)
      .then((res) => {
        if (res.data.success) {
          toast.success(res.data.message, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            theme: "dark",
          });

          setTimeout(() => {

            nav("/provider")
          }, 1500)

        } else {
          toast.error(res.data.message);
        }
      })
      .catch((err) => {
        console.log(err);
        toast.error("Something went wrong");
      });
  };

  return (
    <>
      {/* Header */}
      <div className="container-fluid category">
        <div className="container text-center py-5" style={{ maxWidth: 900 }}>
          <h3 className="text-white display-3 mb-4">Update Services</h3>
        </div>
      </div>


      <div className="container-fluid  ">
        <div className="container py-5">
          <div className="p-5  rounded">
            <div className="row g-4">
              <div className="offset-md-3 me-5 col-md-6 form ps-4 pe-4 pt-5 pb-5 ">
                <ToastContainer
                  position="top-center"
                  autoClose={5000}
                  hideProgressBar={false}
                  newestOnTop={false}
                  closeOnClick
                  rtl={false}
                  pauseOnFocusLoss
                  draggable
                  pauseOnHover
                  theme="dark"
                />
                <center><h1 className="mb-3">Update Service</h1></center>


                <img
                  src={ image} height={"150px"} width={"150"} alt="Service Image" />



                <form onSubmit={handleSubmit}>


                  <div className="mb-3">
                    <label htmlFor="serviceName" className="form-label text-dark" >Service Name </label>


                    <input
                      type="text"
                      className="form-control"
                      id="serviceName"
                      value={serviceName}
                      onChange={(e) => setServiceName(e.target.value)}
                    />
                  </div>

                  <div className="mb-3">
                    <label for="exampleInputPassword1" className="form-label text-dark">Category </label>
                    <div className="mb-3">
                      <select className="form-select" style={{ width: "100%" }}

                        value={categoryProvider} onChange={(e) => { setCategoryProvider(e.target.value) }}>
                        <option value={""}>Select Category</option>
                        {category.map(category => (
                          <option key={category._id} value={category._id}>{category.name}</option>
                        ))}

                      </select>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label htmlFor="description" className="form-label text-dark"> Description</label>


                    <input
                      id="description"
                      className="form-control"
                      rows="4"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="price" className="form-label text-dark"> price</label>


                    <input
                      type="number"
                      id="price"
                      className="form-control"
                      rows="4"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="serviceImage" className="form-label text-dark">Image</label>


                    <input
                      type="file"
                      className="form-control"
                      id="serviceImage"
                      onChange={(e) => setNewImage(e.target.files[0])}
                    />
                  </div>

                  <button type="submit" className="btn btn-primary"> Update</button>


                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}