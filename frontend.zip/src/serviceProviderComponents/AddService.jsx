import { toast, ToastContainer } from "react-toastify";
import APIService from "../APIService";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ClipLoader } from "react-spinners";

export default function AddService() {

  var [name, setName] = useState("");
  var [description, setDescription] = useState("");
  var [price, setPrice] = useState("");
  var [categoryProvider, setCategoryProvider] = useState([])
  var [ProviderId, setProviderId] = useState("")
  var [image, setImage] = useState("");
  var [category, setCategory] = useState([]);
  var [provider, setProvider] = useState([""]);
  var [visible, setvisible] = useState(true)

  const nav = useNavigate()

  useEffect(() => {
    var token = sessionStorage.getItem("token")

    if (!token) {
      setvisible(false)
      toast.error("Please Login first!!!",
        {
          position: "top-center",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "dark",


        }
      )
      setTimeout(() => {
        nav('/login');
      }, 2000);
    }
    else {
      setvisible(true)
    }

    APIService.AllCategryProvider()

      .then((res) => {
        console.log("data is", res.data.data);

        setCategory(res.data.data)

      })
      .catch((err) => {
        console.log(err);

      })

    APIService.AllServiceProvider()

      .then((res) => {
        console.log("data is", res.data.data);

        setProvider(res.data.data)

      })
      .catch((err) => {
        console.log(err);

      })


  }, []);


  const handSubmit = (e) => {
    e.preventDefault();
    console.log('Selected Category:', categoryProvider);


    let data = new FormData()
    data.append("name", name)
    data.append("description", description)
    data.append("price", price)
    data.append("image", image)

    data.append("categoryId", categoryProvider)
    // data.append("serviceProviderId", ProviderId)
    data.append("serviceProviderId", sessionStorage.getItem("ServiceProviderid"))


    APIService.AddServiceProvider(data)
      .then((res) => {
        console.log(res);
        if (res.data.success) {
          console.log("true", res.data.message);
          toast.success(res.data.message, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",

          })


          setName("")
          setImage("")
          setCategoryProvider([])
          setPrice("")
          setDescription("")
          setCategory([])

          setTimeout(() => {

            nav("/provider")
          }, 1500)

        }
        else {

          console.log("false", res.data.message);
          toast.error(res.data.message)

        }


      })
      .catch((err) => {
        console.log(err);

      })



  }

  return (
    <>

      {/* Header Start */}
      <div className="container-fluid bg-serviceAdd">
        <div className="container text-center py-5" style={{ maxWidth: 900 }}>
          <h3 className="text-white display-3 mb-4">Add Service</h3>
        </div>
      </div>
      {/* Header End */}

      <div className="container-fluid  py-1">
        <div className="container py-5">
          <div className="p-5  rounded">
            <div className="row g-4 ms-3">
              <div className="offset-md-3  col-md-6 pb-5  pt-2 form">
                <ToastContainer
                  position="top-center"
                  autoClose={5000}
                  hideProgressBar={false}
                  newestOnTop={false}
                  closeOnClick
                  rtl={false}
                  pauseOnFocusLoss
                  draggable
                  pauseOnHover
                  theme="dark"

                />

                {visible ? (
                  <form onSubmit={handSubmit}>


                    <center><h1 className="mb-3">Add Service</h1></center>

                    <div className="mb-3">
                      <label for="exampleInputEmail1" className="form-label text-dark " > Service Name</label>
                      <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value={name} onChange={(e) => { setName(e.target.value) }} />

                    </div>

                    <div className="mb-3">
                      <label for="exampleInputPassword1" className="form-label text-dark">Category </label>
                      <div className="mb-3">
                        <select className="form-select" style={{ width: "100%" }}

                          value={categoryProvider} onChange={(e) => { setCategoryProvider(e.target.value) }}>
                          <option value={""}>Select Category</option>
                          {category.map(category => (
                            <option key={category._id} value={category._id}>{category.name}</option>
                          ))}

                        </select>
                      </div>
                    </div>

                    <div className="mb-3">
                      <label for="exampleInputEmail1" className="form-label text-dark ">Description</label>
                      <input type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value={description} onChange={(e) => { setDescription(e.target.value) }} />
                    </div>

                    <div className="mb-3">
                      <label for="exampleInputEmail1" className="form-label text-dark">Price</label>
                      <input type="number" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value={price} onChange={(e) => { setPrice(e.target.value) }} min={0} max={100000} />
                    </div>

                    <div className="mb-3">
                      <label for="exampleInputPassword1" className="form-label text-dark">Image  </label>
                      <input type="file" className="form-control" id="exampleInputPassword1" onChange={(e) => { setImage(e.target.files[0]) }} required />
                    </div>

                    <button type="submit" className="btn btn-primary" >Submit</button>

                  </form>
                ) : (<ClipLoader size={150}></ClipLoader>)}


              </div>
            </div>
          </div>
        </div>
      </div>

    </>
  )
}