import './App.css'

import Home from './customerComponents/Home';
import About from './customerComponents/About';

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import CustomerMaster from './masters/CustomerMaster';
import Category from './customerComponents/Category';
import AdminMaster from './masters/AdminMaster';
import ManageCategory from './adminComponents/ManageCategory';
import AddCategory from './adminComponents/AddCategory';
import ManageService from './serviceProviderComponents/ManageService';
import AddService from './serviceProviderComponents/AddService';
import ServiceProviderMaster from './masters/ServiceProviderMaster';
import ManageBooking from './serviceProviderComponents/ManageBooking';
import ManageProfile from './serviceProviderComponents/ManageProfile';
import Booking from './adminComponents/Booking';
import ManageCustomer from './adminComponents/ManageCustomer';
import ManageProvider from './adminComponents/ManageProvider';
import Review from './customerComponents/Review';
import Contact from './customerComponents/Contact';
import Dashboard from './adminComponents/Dashboard';
import Login from './adminComponents/Login';
import 'react-toastify/dist/ReactToastify.css';
import CustomerRegister from './customerComponents/CustomerRegister';
import ProviderRegister from './serviceProviderComponents/ProviderRegister';
import Admin from './adminComponents/Admin';
import ViewProvider from './adminComponents/ViewProvider';
import UpdateCategory from './adminComponents/UpdateCategory';
import ManageReview from './adminComponents/ManageReview';
import BookingC from './customerComponents/BookingC';
import Services from './customerComponents/Services';
import UpdateCustomer from './customerComponents/UpdateCustomer';
import UpdateServices from './serviceProviderComponents/UpdateServices';
import ViewReview from './serviceProviderComponents/viewReview';
import ViewBooking from './customerComponents/ViewBooking';
import ServiceP from './customerComponents/ServiceP';
import ServicesA from './adminComponents/ServicesA';
import BookingA from './adminComponents/BookingA';

function App() {


  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<CustomerMaster />}>
            <Route path='/login' element={<Login />} />
            <Route path="/" element={<Home />} />
            <Route path='/about' element={<About />} />
            <Route path='/category' element={<Category />} />
            <Route path='/review/:serid?/:providerid?' element={<Review />} />
            <Route path='/contact' element={<Contact />} />
            <Route path='/customerregister' element={<CustomerRegister />} />
            <Route path='/providerregister' element={<ProviderRegister />} />
            <Route path='/booking/:serviceid?/:catid?/:serid?' element={<BookingC />} />
            <Route path='/services/:id/' element={<Services />} />
            <Route path='/customerprofle' element={<UpdateCustomer />} />
            <Route path='/viewbooking/' element={<ViewBooking />} />
            <Route path='/servicep/:id/' element={<ServiceP />} />
          </Route>

          <Route path='/admin' element={<AdminMaster />}>
            <Route path='/admin' element={<Admin />} />
            <Route path='/admin/manage' element={<ManageCategory />} />
            <Route path='/admin/addcategory' element={<AddCategory />} />
            <Route path='/admin/manage' element={<ManageCategory />} />
            <Route path='/admin/booking' element={<Booking />} />
            <Route path='/admin/customer' element={<ManageCustomer />} />
            <Route path='/admin/provider' element={<ManageProvider />} />
            <Route path='/admin/viewprovider/:id/' element={<ViewProvider />} />
            <Route path='/admin/updatecategory/:id/' element={<UpdateCategory />} />
            <Route path='/admin/review' element={<ManageReview />} />
            <Route path='/admin/services/:id/' element={<ServicesA />} />
            <Route path='/admin/bookinga/:id/' element={<BookingA />} />
          </Route>

          <Route path='/provider' element={<ServiceProviderMaster />}>
            <Route path='/provider' element={<ManageService />} />
            <Route path='/provider/addservice' element={<AddService />} />
            <Route path='/provider/booking' element={<ManageBooking />} />
            <Route path='/provider/profile' element={<ManageProfile />} />
            <Route path='/provider/update/:id' element={<UpdateServices />} />
            <Route path='/provider/review' element={<ViewReview />} />
          </Route>

        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
