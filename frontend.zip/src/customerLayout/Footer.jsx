import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <>
      <>
        {/* Footer Start */}
        <div className="container-fluid footer py-5">
          <div className="container py-5">
            <div className="row g-5 justify-content-center">

              <div className="col-md-6 col-lg-6 col-xl-3">
                <div className="footer-item d-flex flex-column">
                  <h4 className="mb-4 text-white">Get In Touch</h4>
                  <a href="">
                    <i className="fas fa-home me-2" />123 MG Road, New Delhi, India
                  </a>
                  <a href="">
                    <i className="fas fa-envelope me-2" /> info@workwise.in
                  </a>
                  <a href="">
                    <i className="fas fa-phone me-2" /> +91 98765 43210
                  </a>
                  <a href="" className="mb-3">
                    <i className="fas fa-print me-2" /> +91 98765 43211
                  </a>
                  <div className="d-flex align-items-center">
                    <i className="fas fa-share fa-2x text-white me-2" />
                    <a
                      className="btn-square btn btn-primary rounded-circle mx-1"
                      href=""
                    >
                      <i className="fab fa-facebook-f" />
                    </a>
                    <a
                      className="btn-square btn btn-primary rounded-circle mx-1"
                      href=""
                    >
                      <i className="fab fa-twitter" />
                    </a>
                    <a
                      className="btn-square btn btn-primary rounded-circle mx-1"
                      href=""
                    >
                      <i className="fab fa-instagram" />
                    </a>
                    <a
                      className="btn-square btn btn-primary rounded-circle mx-1"
                      href=""
                    >
                      <i className="fab fa-linkedin-in" />
                    </a>
                  </div>
                </div>
              </div>
              {!sessionStorage.getItem("token") ?
                <div className="col-md-6 col-lg-6 col-xl-3">
                  <div className="footer-item d-flex flex-column">
                    <h4 className="mb-4 text-white">Quick Links</h4>
                    <Link to={"/"}>
                      <i className="fas fa-angle-right me-2" /> Home
                    </Link>

                    <Link to={"/about"}>
                      <i className="fas fa-angle-right me-2" /> About
                    </Link>

                    <Link to={"/category"}>
                      <i className="fas fa-angle-right me-2" /> Category
                    </Link>

                    

                  </div>
                </div>
                :
                <div className="col-md-6 col-lg-6 col-xl-3">
                  <div className="footer-item d-flex flex-column">
                    <h4 className="mb-4 text-white">Quick Links</h4>
                    <Link to={"/provider/addservice"}>
                      <i className="fas fa-angle-right me-2" /> Add Service
                    </Link>

                    <Link to={"/provider"}>
                    <i className="fas fa-angle-right me-2" /> Manage Service
                    </Link>

                    <Link to={"/provider/booking"}>
                      <i className="fas fa-angle-right me-2" /> Booking
                    </Link>

                    <Link to={"/provider/review"}>
                      <i className="fas fa-angle-right me-2" /> Review
                    </Link>

                    <Link to={"/provider/profile"}>
                      <i className="fas fa-angle-right me-2" /> Profile
                    </Link>
                   
                  </div>
                </div>
              }


              <div className="col-md-6 col-lg-6 col-xl-3">
                <div className="footer-item d-flex flex-column">
                  <h4 className="mb-4 text-white">Social</h4>
                  <Link to={"https://www.instagram.com/"}>
                      <i className="fas fa-angle-right me-2" /> Instagram
                    </Link>

                    <Link to={"https://www.facebook.com/"}>
                      <i className="fas fa-angle-right me-2" /> Facebook
                    </Link>

                    <Link to={"https://www.x.com/"}>
                      <i className="fas fa-angle-right me-2" /> Twitter
                    </Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        {/* Footer End */}
        {/* Copyright Start */}
        {/* <div className="container-fluid copyright text-body py-4">
    <div className="container">
      <div className="row g-4 align-items-center ">
        <div className="col-md-6 text-center text-md-end mb-md-0">
          <i className="fas fa-copyright me-2" />
          <a className="text-white" href="#">
            Your Site Name
          </a>
          , All right reserved.
        </div>
       
      </div>
    </div>
  </div> */}
        {/* Copyright End */}
      </>

    </>
  )
}