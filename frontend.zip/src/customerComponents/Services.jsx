import { useEffect, useState } from "react";
import APIService from "../APIService";
import { Link, useParams } from "react-router-dom";
import Category from "./Category";

export default function Services() {

    var [data, setData] = useState([])
    const {id} = useParams()

    // const id = param.id;
    console.log("category jkj",id);

    
    

    useEffect(() => {


        APIService.AllServiceCutomer({categoryId:id})

            .then((res) => {
                console.log("data isjk ", res.data);

                setData(res.data.data)
                
                

            })
            .catch((err) => {
                console.log("error is", err);


            })
      
        

    }, [])
   
    return (
        <>

            <>
                {/* Header Start */}
                <div className="container-fluid service">
                    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
                        <h3 className="text-white display-3 mb-4">Our Services</h3>
                        
                    </div>
                </div>
                {/* Header End */}
            </>

            <div className="row container">
                <div className="col-md-3"></div>
                <div className="col-md-8 mt-5">
                    {

                        data.map((el) => (
                            <div className="card  mb-4 ms-4 " style={{ maxWidth: 700 }}>
                                <div className="row g-0">
                                    <div className="col-md-4">
                                        <img src={el.image}  style={{height:"250px", width:"200px"}} className="img-fluid rounded-start" alt="..." />
                                    </div>
                                    <div className="col-md-8">
                                        <div className="card-body">
                                            <h5 className="card-title" style={{color:"#1c428d"}}>{el.name}</h5>
                                            <h6 className="ps-2">Price:{el.price}/-</h6>
                                            <p className="card-text ps-2">
                                               {el.description}
                                            </p>
                                          <h6 className="ps-2"> Provider: {el.serviceProviderId?.name}</h6>
                                        </div>
                                        <Link to={`/booking/${el.serviceProviderId._id}/${id}/${el._id}`} className="btn btn-primary mt-2 mb-2 ms-4">Book Service</Link>
                                    </div>
                                </div>
                            </div> 

                        ))

                    }

                </div>
                <div className="col-md-2"></div>
            </div>



        </>
    )
}