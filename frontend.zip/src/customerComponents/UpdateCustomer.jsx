import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import APIService from "../APIService";
import { toast, ToastContainer } from "react-toastify";

export default function UpdateCustomer() {
    var [name, setName] = useState("");
    var [email, setemail] = useState("");
    var [contact, setcontact] = useState("");
    var [address, setaddress] = useState("");

        var _id = sessionStorage.getItem("customerid")

    console.log(_id);
    

    useEffect(() => {

        APIService.SingleCustomer({ _id: _id })

            .then((res) => {

                setName(res.data.data.name);
                setemail(res.data.data.email);
                setcontact(res.data.data.contact);
                setaddress(res.data.data.address);
                
            })
            .catch((err) => {
                console.log(err);

            })

    }, []);



    const handSubmit = (e) => {
        e.preventDefault();


        let data = {
            _id:_id,
            name:name,
            email:email,
            contact:contact,
            address:address,
        }

        APIService.UpdateCustomer(data)
            .then((res) => {

                if (res.data.success) {
                    console.log("true", res.data.message);
                    toast.success(res.data.message, {
                        position: "top-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "dark",

                    })

                }
                else {


                    toast.error(res.data.message)

                }


            })
            .catch((err) => {
                console.log(err);
                toast.error(" somthing went wrong")

            })

    }
    return (
        <>

            <>
                {/* Header Start */}
                <div className="container-fluid about1 ">
                    <div className="container text-center py-5"style={{ maxWidth: 900 }}>
                        <h3 className="text-white display-3 mb-4">Customer Profile</h3>
                        <ol className="breadcrumb justify-content-center mb-0">
                            <li className="breadcrumb-item">
                                <a href="index.html">home</a>
                            </li>
                            <li className="breadcrumb-item">
                                <a href="#">Pages</a>
                            </li>
                            <li className="breadcrumb-item active text-white"></li>
                        </ol>
                    </div>
                </div>
                {/* Header End */}
            </>

            <div className="container-fluid ">
                <div className="container py-5">
                    <div className="p-5  rounded">
                        <div className="row g-4">
                            <div className="offset-md-3 col-md-6 ps-4 ps-4 pt-3 pb-4   form">
                                <ToastContainer
                                    position="top-center"
                                    autoClose={5000}
                                    hideProgressBar={false}
                                    newestOnTop={false}
                                    closeOnClick
                                    rtl={false}
                                    pauseOnFocusLoss
                                    draggable
                                    pauseOnHover
                                    theme="dark"

                                />

                               
                                <form onSubmit={handSubmit} >

                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label text-dark"> Name</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value={name} onChange={(e) => { setName(e.target.value) }} />

                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label text-dark">email</label>
                                        <input type="text" class="form-control" id="exampleInputPassword1" value={email} onChange={(e) => { setemail(e.target.value) }} />
                                    </div>


                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label text-dark">Contact</label>
                                        <input type="text" class="form-control" id="exampleInputPassword1" value={contact} onChange={(e) => { setcontact(e.target.value)}} />
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label text-dark">Address </label>
                                        <input type="text" class="form-control" id="exampleInputPassword1" value={address} onChange={(e) => { setaddress(e.target.value) }} />
                                    </div>
                                  


                                    <button type="submit" class="btn btn-primary" >Update</button>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>






        </>
    )
}