export default function Contact(){
    return(
        <>
   
    <>
  {/* Header Start */}
  <div className="container-fluid contact">
    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
      <h3 className="text-white display-3 mb-4">Contact</h3>
      <ol className="breadcrumb justify-content-center mb-0">
        <li className="breadcrumb-item">
          <a href="index.html">home</a>
        </li>
        <li className="breadcrumb-item">
          <a href="#">Pages</a>
        </li>
        <li className="breadcrumb-item active text-white"></li>
      </ol>
    </div>
  </div>
  {/* Header End */}
</>

  
        
    </>
    )
}