import { useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import Contact from "./Contact";
import APIService from "../APIService";

export default function CustomerRegister() {

  const [name, setname] = useState('');
  const [email, setemail] = useState('');
  const [password, setpassword] = useState('');
  const [phone, setphone] = useState('');
  const [address, setaddress] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    let data = {
      name: name,
      email: email,
      password: password,
      contact: phone,
      address: address

    }

    APIService.CustomerRegister(data)
      .then((res) => {
        console.log(res);

        if (res.data.success) {
          console.log("true", res.data.message);
          toast.success(res.data.message, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",

          })

        }

        else {

          console.log("false", res.data.message);
          toast.error(res.data.message)

        }


      })
      .catch((err) => {
        console.log(err);

      }, [])

    setname('');
    setemail('');
    setpassword('');
    setphone('');
    setaddress('');

  }

  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid register">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Customer Registration</h3>
            <ol className="breadcrumb justify-content-center mb-0">
              <li className="breadcrumb-item">
                <a href="index.html">home</a>
              </li>
              <li className="breadcrumb-item">
                <a href="#">Pages</a>
              </li>
              <li className="breadcrumb-item active text-white"></li>
            </ol>
          </div>
        </div>
        {/* Header End */}

      </>



      <div className="container-fluid about py-2">
        <div className="container">
          <div className="row mt-5">
            <div className="col-md-3"></div>
            <div className="col-md-6 form">
              <ToastContainer

                position="top-center"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="dark"
              />

              <center><h2 className="pt-3">Register</h2></center>

              <form className="mt-3 ms-2 me-2" onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group mt-2">
                      <label htmlFor="exampleInputEmail1" className="text-dark">Name</label>
                      <input
                        type="text"
                        className="form-control"
                        id="exampleInputEmail1"
                        aria-describedby="emailHelp"

                        value={name}
                        onChange={(e) => { setname(e.target.value) }}
                        required
                      />

                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group mt-2">
                      <label htmlFor="exampleInputEmail1" className="text-dark">Contact</label>
                      <input
                        type="text"
                        className="form-control"
                        id="exampleInputEmail1"
                        aria-describedby="emailHelp"

                        value={phone}
                        onChange={(e) => { setphone(e.target.value) }}
                        required
                        minLength={10}
                        maxLength={10}
                      />

                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group mt-2">
                      <label htmlFor="exampleInputPassword1" className="text-dark">Email</label>
                      <input
                        type="email"
                        className="form-control"
                        id="exampleInputPassword1"

                        value={email}
                        onChange={(e) => { setemail(e.target.value) }}
                        required
                      />
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group mt-2">
                      <label htmlFor="exampleInputEmail1" className="text-dark">Password</label>
                      <input
                        type="password"
                        className="form-control"
                        id="exampleInputEmail1"
                        aria-describedby="emailHelp"

                        value={password}
                        onChange={(e) => { setpassword(e.target.value) }}
                        required
                      />

                    </div>
                  </div>
                  <div className="col-md-12">
                    <div className="form-group mt-2">
                      <label htmlFor="exampleInputEmail1" className="text-dark">Address</label>
                      <input
                        type="textarea"
                        className="form-control"
                        id="exampleInputEmail1"
                        aria-describedby="emailHelp"

                        value={address}
                        onChange={(e) => { setaddress(e.target.value) }}
                        required
                      />
                    </div>
                  </div>
                </div>

                <button type="submit" className="btn btn-primary mt-3 mb-5">
                  Submit
                </button>
              </form>


            </div>
            <div className="col-md-4"></div>

          </div>
        </div>
      </div>
    </>





  )
}