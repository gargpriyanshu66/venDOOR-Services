import { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify"
import APIService from "../APIService";
import { useParams } from "react-router-dom";

export default function Review(){
  const [name, setname] = useState("")
  const [review, setreview] = useState("")
  const [rating, setrating] = useState("")
  const [service, setservice] = useState([""])
  const [Sservice, setSservice] = useState("")
  const [serviceProvider, setServiceProvider] = useState([""])
  const [SServiceProvider, setSServiceProvider] = useState("")
var param = useParams()

  const serId = param.serid
  const providerId = param.providerid
  console.log("hjh",serId);
  console.log(providerId);

  useEffect(() => {
  
    APIService.AllServiceCutomer()
      .then((res) => {
        console.log("data is", res.data.data);
        setservice(res.data.data)

      })
      .catch((err) => {
        console.log(err);

      })
      APIService.AllServiceProviderCutomer()
      .then((res) => {
        // console.log("data is", res.data.data);
        setServiceProvider(res.data.data)

      })
      .catch((err) => {
        console.log(err);

      })

  
  }, []);
  const customerId = sessionStorage.getItem("customerid")

  const handSubmit = (e) => {
    e.preventDefault();
    let data = {
      customerId:customerId,
      review:review,
      rating:rating,
      serviceId:serId,
      providerId:providerId
    }
    APIService.AddReview(data)
      .then((res) => {
        console.log(res);
        if (res.data.success) {
          console.log("true", res.data.message);
          toast.success(res.data.message, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",

          })
          setname("")
          setrating("")
          setreview("")
        
        }
        else {

          console.log("false", res.data.message);
          toast.error(res.data.message)

        }


      })
      .catch((err) => {
        console.log(err);

      })

    

  }

    return(
        <>
   
    <>
  {/* Header Start */}
  <div className="container-fluid review">
    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
      <h3 className="text-white display-3 mb-4">Review</h3>
      <ol className="breadcrumb justify-content-center mb-0">
        <li className="breadcrumb-item">
          <a href="index.html">home</a>
        </li>
        <li className="breadcrumb-item">
          <a href="#">Pages</a>
        </li>
        <li className="breadcrumb-item active text-white"></li>
      </ol>
    </div>
  </div>
  {/* Header End */}
</>
<div className="container-fluid about py-5">
        <div className="container mb-4">
          <div className="row mt-5">
            <div className="col-md-3 me-5"></div>
            <div className="col-md-5 form" style={{backgroundColor:"#D3D3D3"}}>

              <center><h2 className="mt-3">Add Review</h2></center>

              <ToastContainer
                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="dark"
              />

              <form className="mt-3 ms-5 me-5" onSubmit={handSubmit}>

              <div className="form-group mt-3 ">
                  <label className="text-dark">Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={name}
                    onChange={(e) => { setname(e.target.value) }}
                  />
                </div>
                
                <div className="form-group mt-3">
                  <label className="text-dark" htmlFor="exampleInputPassword1">Review</label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={review}
                    onChange={(e) => { setreview(e.target.value) }}
                  />
                </div>

                <div className="form-group mt-3 mb-3">
                  <label  className="text-dark" htmlFor="exampleInputPassword1">Rating</label>
                  <input
                    type="number"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={rating}
                    onChange={(e) => { setrating(e.target.value) }}
                    min={0}
                    max={5}
                  />
                </div>

                <button type="submit" className="btn btn-primary mt-3 mb-5" style={{width:"90px"}}>
                  Add
                </button>
              </form>


            </div>
            <div className="col-md-3"></div>

          </div>
        </div>
      </div>



  
        
    </>
    )
}