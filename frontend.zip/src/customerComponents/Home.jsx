export default function Home(){
  return(
    <>
    <>
  {/* Carousel Start */}
  <div className="carousel-header">
    <div id="carouselId" className="carousel slide" data-bs-ride="carousel">
      <ol className="carousel-indicators">
        <li
          data-bs-target="#carouselId"
          data-bs-slide-to={0}
          className="active"
        />
        <li data-bs-target="#carouselId" data-bs-slide-to={1} />
        <li data-bs-target="#carouselId" data-bs-slide-to={2} />
      </ol>
      <div className="carousel-inner" role="listbox">
        <div className="carousel-item active">
          <img src="/assets/img/main.jfif" className="img-fluid" alt="Image" />
          <div className="carousel-caption">
            <div className="p-3" style={{ maxWidth: 900 }}>
              <h4
                className="text-white text-uppercase fw-bold mb-4"
                style={{ letterSpacing: 3 }}
              >
               welcome to the 
              </h4>
              <h1 className="display-2 text-capitalize text-white mb-4">
               WorkWise
              </h1>
              {/* <p className="mb-5 fs-5">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s,
              </p> */}
              {/* <div className="d-flex align-items-center justify-content-center">
                <a
                  className="btn-hover-bg btn btn-primary rounded-pill text-white py-3 px-5"
                  href="#"
                >
                  Discover Now
                </a>
              </div> */}
            </div>
          </div>
        </div>
        <div className="carousel-item">
          <img src="/assets/img/main2.jfif" className="img-fluid" alt="Image" />
          <div className="carousel-caption">
            <div className="p-3" style={{ maxWidth: 900 }}>
              <h4
                className="text-white text-uppercase fw-bold mb-4"
                style={{ letterSpacing: 3 }}
              >
                Welcome
              </h4>
              <h1 className="display-2 text-capitalize text-white mb-4">
                Find Your Best Service
              </h1>
            
             
            </div>
          </div>
        </div>
        <div className="carousel-item">
          <img src="/assets/img/main4.jfif" className="img-fluid" alt="Image" />
          <div className="carousel-caption">
            <div className="p-3" style={{ maxWidth: 900 }}>
              <h4
                className="text-white text-uppercase fw-bold mb-4"
                style={{ letterSpacing: 3 }}
              >
                Welcome
              </h4>
              <h1 className="display-2 text-capitalize text-white mb-4">
                You Like To Go?
              </h1>
              
            
            </div>
          </div>
        </div>
      </div>
      <button
        className="carousel-control-prev"
        type="button"
        data-bs-target="#carouselId"
        data-bs-slide="prev"
      >
        <span
          className="carousel-control-prev-icon btn bg-primary"
          aria-hidden="false"
        />
        <span className="visually-hidden">Previous</span>
      </button>
      <button
        className="carousel-control-next"
        type="button"
        data-bs-target="#carouselId"
        data-bs-slide="next"
      >
        <span
          className="carousel-control-next-icon btn bg-primary"
          aria-hidden="false"
        />
        <span className="visually-hidden">Next</span>
      </button>
    </div>
  </div>
  {/* Carousel End */}
  <div
    className="container-fluid search-bar position-relative"
    style={{ top: "-50%", transform: "translateY(-50%)" }}
  >
   
  </div>
  {/* Navbar & Hero End */}
</>
<div class="col mt-5 pb-4"><center><h1 className="text-dark text-uppercase fw-bold mb-4">Facilities</h1></center></div>
<div className="container-fluid  pb-5">
  <div className="container ">
    <div className="row g-4 ">
      <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
        <div className="service-item rounded pt-3 ">
          <div className="p-4" style={{backgroundColor:"rgba(19, 53, 123, 10)"}}>
            <i className="fa fa-3x fa-user-tie   text-light mb-4" />
            <h5 className="text-light">Professional Team</h5>
            <p className="text-light">
            Our skilled, experienced team ensures high-quality service you can trust.
            </p>
          </div>
        </div>
      </div>
      <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.3s" >
        <div className="service-item rounded pt-3">
          <div className="p-4"  style={{backgroundColor:"rgba(19, 53, 123, 10)"}}>
            <i className="fa fa-3x fa-gift pinkt  mb-4  text-light" />
            <h5 className="text-light"> Special Offers</h5>
            <p className="text-light">
            Enjoy exclusive deals and discounts on top vendor services every day.
            </p>
          </div>
        </div>
      </div>
      <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
        <div className="service-item rounded pt-3 ">
          <div className="p-4"  style={{backgroundColor:"rgba(19, 53, 123, 10)"}}>
            <i className="fa fa-3x fa-cart-plus pinkt mb-4 text-light" />
            <h5 className="text-light">Online Booking</h5>
            <p className="text-light"> 
            Easily book your favorite services anytime, anywhere with our platform.
            </p>
          </div>
        </div>
      </div>
      <div className="col-lg-3 col-sm-6 wow fadeInUp" data-wow-delay="0.7s">
        <div className="service-item rounded pt-3 ">
          <div className="p-4"  style={{backgroundColor:"rgba(19, 53, 123, 10)"}}>
            <i className="fa fa-3x fa-headset pinkt mb-4 text-light" />
            <h5 className="text-light">24/7 Service</h5>
            <p className="text-light">
            We provide reliable, round-the-clock service for your convenience and needs.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div className="container-fluid  pb-5">
  <div className="row ">
    <div className="col-sm">
      <center>
        <h1 className="text-dark text-uppercase fw-bold mb-5">Gallerry</h1>
      </center>
    </div>
  </div>
  <div className="row">
    <div className="col-md-3">
      <img src="/assets/img/g1.jfif" className="img2 img-fluid" />
    </div>
    <div className="col-md-3">
      <img src="/assets/img/g2.jfif"  height={"195px"} width={"100%"} />
    </div>
    <div className="col-md-3">
      <img src="/assets/img/g3.webp" className="img2 img-fluid" />
    </div>
    <div className="col-md-3">
      <img src="/assets/img/g4.jfif" className="img2 img-fluid" />
    </div>
  </div>
  <div className="row">h</div>
  <div className="row ">
    <div className="col-md-3">
      <img src="/assets/img/g7.jfif" className="img2 img-fluid" />
    </div>
    <div className="col-md-3">
      <img src="/assets/img/g8.jfif" className="img2 img-fluid" />
    </div>
    <div className="col-md-3">
      <img src="/assets/img/g5.jpg" className="img2 img-fluid" />
    </div>
    <div className="col-md-3">
      <img src="/assets/img/g6.jfif"  height={"195px"} width={"100%"}  />
    </div>
  </div>
</div>



    
    </>
  )
}