import { useEffect, useState } from "react"
import APIService from "../APIService";
// import moment from 'moment';
import { Link } from "react-router-dom";

export default function ViewBooking() {

  const [data, setdata] = useState([])

  const id = sessionStorage.getItem("customerid")
  console.log("id is", id);

  useEffect(() => {

    APIService.AllBookingcustomer({ customerId: id })
      .then((res) => {
        // console.log("data is ", res.data.data)
        setdata(res.data.data)
      })
      .catch((err) => {
        console.log("error is", err);
      })
  }, [])
  const getDate = (date)=>{
    var d = date.split('T')
    return d[0]
  }
  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid booking">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Bookings</h3>
          </div>
        </div>
        {/* Header End */}
      </>
      <div className="row mt-5 container">
        <div className="col-md-1"></div>
        <div className="col-md-10 mx-auto table-responsive">
          <table className="table table-bordered " style={{ backgroundColor: '#808080' }}>
            <tr>
              <th className="ps-5 pt-3 text-light">Sno</th>
              <th className="ps-5 pt-3 text-light">Customer Name</th>
              <th className="ps-5 pt-3 text-light">Provider</th>
              <th className="ps-5 pt-3 text-light">Service</th>
              <th className="ps-5 pt-3 text-light">Price</th>
              <th className="ps-5 pt-3 text-light">Contact</th>
              <th className="ps-5 pt-3 text-light">Address</th>
              <th className="ps-5 pt-3 text-light">Time</th>
              <th className="ps-5 pt-3 text-light ">Date</th>
              <th className="ps-5 pt-3 text-light ">Status</th>
              <th className="ps-5 pt-3 text-light ">Payment Status</th>

              <th className="ps-4 pt-3 text-light pe-5">Review</th>
            </tr>
            {
              data.map((el, index) => (
                <tr>
                  <td className="ps-5 pt-3 text-light">{index + 1}</td>
                  <td className="ps-5 pt-3 text-light">{el?.customerName}</td>
                  <td className="ps-5 pt-3 text-light">{el?.providerId.name} <br /> {el.providerId.email} <br /> {el.providerId.contact}</td>
                  <td className="ps-5 pt-3 text-light">{el.serviceId.name} <br /><small>({el.categoryId.name})</small></td>
                  <td className="ps-5 pt-3 text-light">Rs. {el.serviceId.price}</td>
                  <td className="ps-5 pt-3 text-light">{el.contact}</td>
                  <td className="ps-5 pt-3 text-light">{el.address}</td>
                  <td className="ps-5 pt-3 text-light">{el.time}</td>
                  <td className="ps-5 pt-3 text-light">{getDate(el.date)}</td>
                  <td className="ps-5 pt-3 text-light">{el.status}</td>
                  <td className="ps-5 pt-3 text-light">{el.paymentStatus}</td>
                  
                  {/* <td  className="ps-5 pe-3 pt-3 text-light">{ moment(el.date).format('MM/DD/YYYY')}</td> */}
                  <td>
                    {el.status == "Completed" ?
                      <Link to={`/review/${el.serviceId._id}/${el.providerId._id}`} className="btn btn-success mt-2 mb-2 ms-4" style={{ backgroundColor: "green" }} >Review</Link> :
                      <Link to={`/review/${el.serviceId._id}/${el.providerId._id}`} className="btn btn-success mt-2 mb-2 ms-4 disabled" style={{ backgroundColor: "green" }} >Review</Link>
                    }
                  </td>

                </tr>
              ))

            }


          </table>
        </div>
      </div >

    </>
  )
}