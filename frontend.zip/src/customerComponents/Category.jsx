import { useEffect, useState } from "react";
import APIService from "../APIService";
import { Link, useParams } from "react-router-dom";

export default function Category() {


 

  var [data, setData] = useState([""])
  useEffect(() => {

    APIService.AllCategryCustomer()


      .then((res) => {
        console.log("data is ", res.data);

        setData(res.data.data)

      })
      .catch((err) => {
        console.log("error is", err);

       


      })

  }, [])

  const containerStyle = {
    display: 'flex',
    justifyContent: 'flex-start',  
    gap: '20px',                   
    padding: '20px',
    overflowX: 'auto',   
             
};


  return (
    <>
      <>
        {/* Header Start */}
        <div className="container-fluid category">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Our Categories</h3>
          </div>
        </div>
     
      
       
        </>
         <div className="row container-fluid">
         
        
          <div className=" col-md card-container " style={containerStyle}>
          {
          data.map((el) => (

           <center><div className=" ms-3 card  mt-5 mb-5" style={{ width: "262px", backgroundColor:"" }}>
              <img className="card-img-top card-img" src={ el.image} alt="Card image cap" />
              <div className="card-body">
                <h5 className=" card-title">{el.name}</h5>
                <p className=" card-description">{el.description}
                </p>
                <p></p>
                <Link to= {"/services/"+ el._id}  className="btn btn-primary">
                  Check the Services 
                </Link>
              </div>
            </div></center> 

          ))

        }

          </div>
         
        </div>

      
     

    </>
  )
}