import { useEffect, useState } from "react"
import APIService from "../APIService"
import { toast, ToastContainer } from "react-toastify"
import { useNavigate, useParams } from "react-router-dom"

export default function BookingC() {
  const [name, setname] = useState("")
  const [contact, setcontact] = useState("")
  const [address, setaddress] = useState("")
  const [service, setservice] = useState([""])
  const [Sservice, setSservice] = useState("")
  const [serviceProvider, setServiceProvider] = useState([""])
  const [SServiceProvider, setSServiceProvider] = useState("")
  const [category, setcategory] = useState([""])
  const [Scategory, setScategory] = useState("")
  const [date, setdate] = useState("")
  const [time, settime] = useState("")
  const [totalAmount, settotalAmount] = useState("")
  const param = useParams();
  const { _id, id } = useParams()

  const nav = useNavigate()

  const catId = param.catid
  const serviceId = param.serviceid
  const serId = param.serid

        var cusid = sessionStorage.getItem("customerid")

    console.log(_id);
    

  useEffect(() => {
    var userType = sessionStorage.getItem("userType")
    if(userType !== 3){
          nav("/login")
    }
   APIService.SingleCustomer({ _id: cusid })

            .then((res) => {

                setname(res.data.data.name);
                // setemail(res.data.data.email);/
                setcontact(res.data.data.contact);
                setaddress(res.data.data.address);
                
            })
            .catch((err) => {
                console.log(err);

            })
    APIService.SingleServices({ _id: serId })
      .then((res) => {
        // console.log("Single Service : ", res.data.data)
        settotalAmount(res.data.data.price)
        // console.log(totalAmount)
      })
      .catch((err) => {
        console.log(err);
      });

    APIService.AllServiceCutomer()
      .then((res) => {
        console.log("data is", res.data.data);
        setservice(res.data.data)

      })
      .catch((err) => {
        console.log(err);
      })

    APIService.AllServiceProviderCutomer()
      .then((res) => {
        // console.log("data is", res.data.data);
        setServiceProvider(res.data.data._id)

      })
      .catch((err) => {
        console.log(err);

      })

    APIService.AllCategryCustomer()
      .then((res) => {
        // console.log("data is", res.data.data);
        setcategory(res.data.data)

      })
      .catch((err) => {
        console.log(err);

      })


  }, []);


  const customerId = sessionStorage.getItem("customerid")

  const handSubmit = (e) => {
    e.preventDefault();
    let data = {
      customerId: customerId,
      customerName: name,
      contact: contact,
      address: address,
      serviceId: serId,
      categoryId: catId,
      providerId: serviceId,
      totalAmount: totalAmount,
      date: date,
      time: time
    }
    APIService.AddBooking(data)
      .then((res) => {
        console.log(res.data);
        if (res.data.success) {
          console.log("true", res.data.message);
          toast.success(res.data.message, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",

          })
          // nav("/viewbooking")

          // setname("")
          // setaddress("")
          // setcontact("")
          // setdate("")
          // settime("")

          paymentHandler(res.data.order)

        }
        else {

          console.log("false", res.data.message);
          toast.error(res.data.message)

        }


      })
      .catch((err) => {
        console.log(err);

      })

  }

  const paymentHandler = (order) => {
    // setLoading(true);
    // const data = { _id };
    // apiService
    //   .pay(data)
    //   .then((res) => {
    //     if (res.data.success) {
    // const order = res.data.order;
    const options = {
      key: "rzp_test_RiJZ0zWB0h8XZ9",
      amount: order.amount,
      currency: "INR",
      name: "Vendor Service",
      description: "Test Transaction",
      image: "https://example.com/your_logo",
      order_id: order.id,

      handler: function (response) {
        console.log("✅ Payment Success:", response);
        toast.success("Payment Successful!");
        nav("/viewbooking")
        setLoading(false);
        fetchRequests();
        
      },
      prefill: {
        name: "Mohit Kumar",
        email: "mohit@gmail.com",
        contact: "1234567890"
      },
      theme: {
        color: "#3399cc"
      }
    };
    const rzp1 = new window.Razorpay(options);
    rzp1.on("payment.failed", function (response) {
      // setLoading(false);
      console.log(response.error)
      toast.error(response.error.description || "Payment failed");
    });

    rzp1.open();

  }

  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid bookingc">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Booking</h3>
          </div>
        </div>
        {/* Header End */}
      </>

      <div className="container-fluid about py-5">
        <div className="container mb-4">
          <div className="row mt-5">
            <div className="col-md-3 "></div>
            <div className="col-md-6 form" >

              <center><h2 className="mt-2">Booking</h2></center>

              <ToastContainer
                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="dark"
              />

              <form className="mt-3 ms-5 me-5" onSubmit={handSubmit}>

                <div className="form-group mt-3 ">
                  <label className="text-dark">Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={name}
                    onChange={(e) => { setname(e.target.value) }}
                  />
                </div>


                <div className="form-group mt-3 ">
                  <label className="text-dark">Contact</label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={contact}
                    onChange={(e) => { setcontact(e.target.value) }}
                    minLength={10}
                    maxLength={10}
                  />
                </div>


                <div className="form-group mt-3 ">
                  <label className="text-dark">Address</label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={address}
                    onChange={(e) => { setaddress(e.target.value) }}
                  />
                </div>


                <div className="form-group mt-3 ">
                  <label className="text-dark">Date</label>
                  <input
                    type="date"
                    className="form-control"
                    id="exampleInputPassword1"
                    min={new Date().toISOString().split('T')[0]}
                    value={date}
                    onChange={(e) => { setdate(e.target.value) }}
                  />
                </div>
                <div className="form-group mt-3 ">
                  <label className="text-dark">Time</label>
                  <input
                    type="time"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={time}
                    onChange={(e) => { settime(e.target.value) }}
                  />
                </div>

                <button type="submit" className="btn btn-primary mt-3 mb-5" style={{ width: "90px" }}>
                  Pay Now
                </button>
              </form>


            </div>
            <div className="col-md-3"></div>

          </div>
        </div>
      </div>



    </>
  )
}