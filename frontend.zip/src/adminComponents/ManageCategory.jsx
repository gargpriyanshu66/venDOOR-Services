import { useEffect, useState } from "react";
import APIService from "../APIService";
import axios from "axios";
import { Link } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import { ClipLoader } from "react-spinners";
import App from "../App";

export default function ManageCategory() {

  var [data, setData] = useState([""])
  const [visible, setvisible] = useState(false)

  useEffect(() => {

    APIService.AllCategry()


      .then((res) => {
        console.log("data is ", res.data);

        setData(res.data.data)
        setvisible(false)
      })
      .catch((err) => {
        console.log("error is", err);
        setvisible(false)
      })


  }, [])

  const handledelte = (id) => {

    APIService.DeleteCategory({ _id: id })
      .then((res) => {
        window.confirm("Are you want to  delete??")
        APIService.AllCategry()
          .then((res) => {
            console.log(res.data);
            setData(res.data.data)
            setvisible(false)

            toast.success("Category Deleted Successfully!", {
              position: "top-center",
              autoClose: 5000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: undefined,
              theme: "dark",


            })

          })
          .catch((err) => {
            console.log(err);
            setvisible(false)

          })
        // sdata();  // 


      })
      .catch((err) => {
        toast.error("Something went wrong!!")


      })
  }

  const style = {
    textAlign: 'center'
  }


  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid acategory">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Manage Category</h3>
          </div>
        </div>
        {/* Header End */}
      </>
      <div className="container-fluid" >


        <ToastContainer />

        <div className="row mt-5">
          <div className="col-md-2"></div>
          <div className="col-md-8">
            {visible ? (<ClipLoader size={100}></ClipLoader>) : (<table className="table table-bordered mt-3 mb-5" style={{ backgroundColor: '#191970' }}>
              <thead>
                <tr>
                  <th className="ps-5 pt-3 text-light">Sno</th>
                  <th className="ps-5 pt-3 text-light"> Category Name</th>
                  <th className="ps-5 pt-3 text-light"> Description</th>
                  <th className="ps-5 pt-3 text-light">Image</th>
                  <th className="ps-5 pt-3 text-light">Action</th>

                </tr>
              </thead>
              <tbody>
                {

                  data.map((el, index) => (
                    <tr key={index}>
                      <td className="ps-5 text-light">{index + 1}</td>
                      <td className="ps-5 text-light">{el.name}</td>
                      <td className="ps-5 text-light">{el.description}</td>
                      <td className="ps-5 "><img src={ el.image} height={"100px"}></img></td>
                      <td><Link to={"/admin/updatecategory/" + el._id} className="btn text-light me-2 ms-3" style={{ width: '71px', backgroundColor: "green" }}>Edit</Link>
                        <button className="btn  " style={{ background: "red", width: "70px", color: "white", }} onClick={() => { handledelte(el._id) }}>Delete</button>

                      </td>
                    </tr>
                  ))


                }
              </tbody>


            </table>)}
          </div>
        </div>
      </div>


    </>
  )
}