import { useEffect, useState } from "react";
import APIService from "../APIService";
import { Link } from "react-router-dom";

export default function ManageProvider() {
  var [data, setData] = useState([])
  var [del, setdel] = useState(true)
  const [visible, setvisible] = useState(false)


  useEffect(() => {

    APIService.AllProvider()

      .then((res) => {
        console.log("data is ", res.data.data);

        setData(res.data.data)

      })
      .catch((err) => {
        console.log("error is", err);


      })


  }, [])



  const handledelete = (id) => {



    console.log("hsdjhdk", id);
    let data = {
      _id: id,
      status: "true"
    }

    APIService.ProviderStatus(data)
      .then((res) => {
        console.log(res);
        setdel(false)

        APIService.AllProvider()
          .then((res) => {
            // console.log("data is", res.data.data.name);
            console.log(res);
            setData(res.data.data)
            setvisible(false)
            setdel(false)

          })
          .catch((err) => {
            console.log(err);
            setvisible(false)
            setdel(false)

          })


      })
      .catch((err) => {
        console.log(err);
        setdel(false)


      })
  }

  const handledelete2 = (id) => {



    console.log("hsdjhdk", id);
    let data = {
      _id: id,
      status: "false"
    }

    APIService.ProviderStatus(data)
      .then((res) => {
        console.log(res);
        setdel(false)

        APIService.AllProvider()
          .then((res) => {
            // console.log("data is", res.data.data.name);
            console.log(res);
            setData(res.data.data)
            setvisible(false)
            setdel(false)

          })
          .catch((err) => {
            console.log(err);
            setvisible(false)
            setdel(false)

          })


      })
      .catch((err) => {
        console.log(err);
        setdel(false)


      })


  }

  const b = (() => {
    alert("Status is False")


  })
  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid provider">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Manage Service Provider</h3>
          </div>
        </div>
        {/* Header End */}
      </>

      <div className="row mt-5 container">
        <div className="col-md-2 me-4"></div>
        <div className="col-md-8">
          <table className="table table-bordered table mb-5"  >
            <tr>
              <th className="ps-5 text-dark">Sno</th>
              <th className="ps-5 text-dark">Name</th>
              <th className="ps-5 text-dark">Image</th>
              <th className="ps-5 text-dark">Status</th>
              <th className="ps-5 text-dark">Action</th>
              <th className="ps-5 text-dark">Detail</th>

            </tr>
            {

              data.map((el, index) => (
                <tr>
                  <td className="ps-5 text-dark">{index + 1}</td>
                  <td className="ps-5 text-dark">{el.name}</td>
                  <td className="ps-5"><img src={ el.image} height={"100px"}></img></td>
                  <td className="ps-5 text-dark">{el.status == true ? "true" : "false"}</td>
                  <td className="ps-2 pe-3">
                    {/* {el.status == true ? <button className="btn mt-3 text-light ms-4" style={{ width: '71px', backgroundColor: "green" }} onClick={() => { handledelete(el._id) }} >Active</button>
                      : <button className="btn text-light  mt-3 ms-4" style={{ width: '71px', backgroundColor: "red" }} onClick={() => { handledelete(el._id) }} >Inactive</button>} */}

                    {el.status == false ? <button className="btn mt-3 text-light ms-4 mb-2" style={{ width: '71px', backgroundColor: "green" }} onClick={() => { handledelete(el._id) }} >Active</button>
                      : <button className="btn text-light  mt-3 mb-2 ms-4" style={{ width: '71px', backgroundColor: "red" }} onClick={() => { handledelete2(el._id) }} >Inactive</button>} </td>


                  <td className="ps-5">{el.status == true ? <Link to={"/admin/viewprovider/" + el._id} className="btn text-light me-4" style={{ backgroundColor: "green", width: "71px" }}>view</Link> : <button className="btn text-light" style={{ backgroundColor: "green", width: "71px" }} onClick={b}>view</ button>} </td>
                </tr>
              ))


            }


          </table>
        </div>
        <div className="col-md-2"></div>
      </div>





    </>
  )
}