import { useEffect, useState } from "react";
import APIService from "../APIService";
import { useParams } from "react-router-dom";

export default function ServicesA() {

    var [data, setData] = useState([])
    const param = useParams()
    const id = param.id;
    console.log("service p", id);

    useEffect(() => {


        APIService.AllServiceAdmin({ serviceProviderId: id })

            .then((res) => {
                console.log("provider ", res.data.data);
                setData(res.data.data)
            })
            .catch((err) => {
                console.log("error is", err);


            })



    }, [])

    return (
        <>

            <>
                {/* Header Start */}
                <div className="container-fluid service">
                    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
                        <h3 className="text-white display-3 mb-4">Services</h3>
                    </div>
                </div>
                {/* Header End */}
            </>

            <div className="row container">
                <div className="col-md-3"></div>
                <div className="col-md-8 mt-5">
                    {

                        data.map((el) => (
                            <div className="card  mb-4 ms-4 " style={{ maxWidth: 700 }}>
                                <div className="row g-0">
                                    <div className="col-md-4">
                                        <img src={ el.image} style={{ height: "250px", width: "200px" }} className="img-fluid rounded-start" alt="..." />
                                    </div>
                                    <div className="col-md-8">
                                        <div className="card-body">
                                            <h5 className="card-title">{el.name}</h5>
                                            <h6 className="ps-2">Price:Rs. {el.price}</h6>
                                            <p className="card-text">
                                                {el.description}
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>


                        ))



                    }

                </div>
                <div className="col-md-2"></div>
            </div>



        </>
    )
}