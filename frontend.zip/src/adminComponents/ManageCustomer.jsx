import { useEffect, useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import APIService from "../APIService";
import { Link } from "react-router-dom";
import { ClipLoader } from "react-spinners";

export default function ManageCustomer() {
  var [data, setData] = useState([""])
  var [del, setdel] = useState(true)
  const [visible, setvisible] = useState(false)

  useEffect(() => {

    APIService.AllCustomer()


      .then((res) => {
        console.log("data is ", res.data);

        setData(res.data.data)
        setvisible(false)
        setdel(false)




      })
      .catch((err) => {
        console.log("error is", err);
        setvisible(false)
        setdel(false)



      })


  }, [])

  // const handledelete = (id) => {

  //   console.log("hsdjhdk", id);

  //   let data = {
  //     _id: id,
  //     status: "true"
  //   }
  //   APIService.CustomerStatus(data)
  //     .then((res) => {
  //       console.log(res);
  //       setdel(false)

  //       APIService.AllCustomer()

  //         .then((res) => {
  //           console.log("data is ", res.data.data);

  //           setData(res.data.data)
  //           setdel(false)


  //         })
  //         .catch((err) => {
  //           console.log("error is", err);
  //           setdel(false)

  //         })


  //     })
  //     .catch((err) => {
  //       console.log(err);
  //       setdel(false)

  //     })
  // }

  // const handledelete2 = (id) => {

  //   console.log("hsdjhdk", id)
  //   let data = {
  //     _id: id,
  //     status: "false"
  //   }
  //   APIService.CustomerStatus(data)
  //     .then((res) => {
  //       console.log(res);
  //       setdel(false)

  //       APIService.AllCustomer()

  //         .then((res) => {
  //           console.log("data is ", res.data.data);

  //           setData(res.data.data)
  //           setdel(false)


  //         })
  //         .catch((err) => {
  //           console.log("error is", err);
  //           setdel(false)

  //         })


  //     })
  //     .catch((err) => {
  //       console.log(err);
  //       setdel(false)

  //     })
  // }

  const changeStatus = (id, status) => {
    setdel(true); // show loader
    let data = {
      _id: id,
      status: status
    };
    APIService.CustomerStatus(data)
      .then((res) => {
        console.log(res);
        toast.success("Status updated successfully!"); // <-- ADD TOAST SUCCESS
        APIService.AllCustomer()
          .then((res) => {
            setData(res.data.data);
            setdel(false);
          })
          .catch((err) => {
            console.log("error is", err);
            toast.error("Failed to fetch customers!"); // <-- ADD TOAST ERROR
            setdel(false);
          });
      })
      .catch((err) => {
        console.log(err);
        toast.error("Failed to update status!"); // <-- ADD TOAST ERROR
        setdel(false);
      });
  };


  const style = {
    textAlign: 'center'
  }
  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid customer">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Manage Customer</h3>
            
          </div>
        </div>
        {/* Header End */}
      </>

      <div className="container-fluid" >


        <ToastContainer />

        <div className="row mt-5">
          <div className="col-md-1"></div>
          <div className="col-md-10">
            {del ? (<ClipLoader size={100}></ClipLoader>) : (<table className="table table-bordered mb-5" style={{ backgroundColor: '#FFDBBB' }}>
              <tr>
                <th className="ps-5 text-dark">Sno</th>
                <th className="ps-5 text-dark">Name</th>
                <th className="ps-5 text-dark">Email</th>
                <th className="ps-5 text-dark">Contact</th>
                <th className="ps-5 text-dark">Address</th>
                <th className="ps-5 text-dark">Status</th>
                <th className="ps-5 text-dark">Action</th>

              </tr>
              {

                data.map((el, index) => (
                  <tr>
                    <td className="ps-5 text-dark">{index + 1}</td>
                    <td className="ps-5 text-dark">{el.name}</td>
                    <td className="ps-5 text-dark">{el.email}</td>
                    <td className="ps-5 text-dark">{el.contact}</td>
                    <td className="ps-5 text-dark">{el.address}</td>
                    <td className="ps-5 text-dark">{el.status == true ? "Active" : "Inactive"}</td>

                    {/* <td  className="ps-5  pe-4 text-dark">
                      {el.status == true ? <button className="btn text-light mb-2 mt-2" style={{ width: '71px', backgroundColor:"red" }} onClick={() => { handledelete(el._id) }} >Block</button>
                       : <button className="btn  text-light mt-2 mb-2" style={{ width: '71px',backgroundColor:"green" }} onClick={() => { handledelete(el._id) }} >UnBlock</button>}

                        {el.status == false ? <button className="btn text-light mb-3 mt-2" style={{ width: '71px', backgroundColor:"red" }} onClick={() => { handledelete2(el._id) }} >Block</button>
                       : <button className="btn  text-light mt-1 mb-2" style={{ width: '71px',backgroundColor:"green" }} onClick={() => { handledelete2(el._id) }} >UnBlock</button>}

                    </td> */}
                    <td>
                      {el.status == true ? (
                        <button className="btn text-light mb-2 mt-2" style={{ width: '71px', backgroundColor: "red" }} onClick={() => changeStatus(el._id, "false")}>Block</button>
                      ) : (
                        <button className="btn text-light mt-2 mb-2" style={{ width: '71px', backgroundColor: "green" }} onClick={() => changeStatus(el._id, "true")}>Unblock</button>
                      )}

                    </td>
                  </tr>
                ))


              }


            </table>)}
          </div>
        </div>
        <div className="col-md-1"></div>
      </div>



    </>
  )
}