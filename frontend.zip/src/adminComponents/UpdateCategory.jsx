import { toast, ToastContainer } from "react-toastify"
import APIService from "../APIService";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

export default function UpdateCategory() {
    var [name, setName] = useState("");
    var [image, setImage] = useState("");
    var [description, setDescription] = useState("");

    const nav = useNavigate()
    const param = useParams()
    const id = param.id;



    useEffect(() => {

       APIService.SingleCategory( {_id: id })

            .then((res) => {
               
                setName(res.data.data.name);
                setDescription(res.data.data.description)
                setImage(res.data.data?.image)
            
            })
            .catch((err) => {
                console.log(err);

            })

    }, []);



    const handSubmit = (e) => {
        e.preventDefault();


        let data = new FormData()
        data.append("_id", id)
        data.append("name", name)
        data.append("description",description)
        data.append("image", image)
       APIService.UpdateCategory(data)
            .then((res) => {
            
                if (res.data.success) {
                    console.log("true", res.data.message);
                    toast.success(res.data.message, {
                        position: "top-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "dark",

                    })

                    setTimeout(()=>{

                        nav("/admin/manage")
                    },1500)
                  
                }
                else {

                   
                    toast.error(res.data.message)

                }


            })
            .catch((err) => {
                console.log(err);
                toast.error(" somthing went wrong")

            })

    }
    return (
        <>

            <>
                {/* Header Start */}
                <div className="container-fluid bg-breadcrumb category">
                    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
                        <h3 className="text-white display-3 mb-4">Update Category</h3>
                    </div>
                </div>
                {/* Header End */}
            </>

            <div className="container-fluid ">
                <div className="container py-5">
                    <div className="p-5  rounded">
                        <div className="row g-4 ms-5">
                            <div className="offset-md-3   col-md-6 ps-4  pe-4 pb-5 form" >
                                <ToastContainer
                                    position="top-right"
                                    autoClose={5000}
                                    hideProgressBar={false}
                                    newestOnTop={false}
                                    closeOnClick
                                    rtl={false}
                                    pauseOnFocusLoss
                                    draggable
                                    pauseOnHover
                                    theme="dark"

                                />
                                <center><h2 className="pt-4 pb-3 text-dark">Update Category</h2></center>

                                <img src={ image} height={"100px"} ></img>
                                <form onSubmit={handSubmit} >

                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label" className="text-dark">  Category Name</label>
                                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value={name} onChange={(e) => { setName(e.target.value) }} />

                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label"  className="text-dark">Description </label>
                                        <input type="text" class="form-control" id="exampleInputPassword1" value={description}  onChange={(e) => { setDescription(e.target.value) }} />
                                    </div>
                                    <div class="mb-3">
                                        <label for="exampleInputPassword1" class="form-label"  className="text-dark">Image  </label>
                                        <input type="file" class="form-control" id="exampleInputPassword1" onChange={(e) => { setImage(e.target.files[0]) }} />
                                    </div>

                            
                                    <button type="submit" className=" btn btn-primary" style={{bgColor:"#1c428d"}}>Update</button>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </>
    )
}