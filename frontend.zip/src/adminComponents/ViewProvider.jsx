import { useEffect, useState } from "react";
import APIService from "../APIService";
import { Link, useParams } from "react-router-dom";
import { ClipLoader } from "react-spinners";


export default function ViewProvider() {
    const [data, setdata] = useState([""])
    var [del, setdel] = useState(true)
    const [visible, setvisible] = useState(false)

    const param = useParams()
    console.log(param);

    const id = param.id;

    useEffect(() => {

        APIService.SingleProvider({ _id: id })
            .then((res) => {
                // console.log("data is", res.data.data.name);
                console.log(res);
                setdata(res.data.data)
                setvisible(false)
                setdel(false)

            })
            .catch((err) => {
                console.log(err);
                setvisible(false)
                setdel(false)

            })
    }, [])

    const handledelete = (id) => {



        console.log("hsdjhdk", id);
        let data = {
            _id: id,
            status: "true"
        }

        APIService.ProviderStatus(data)
            .then((res) => {
                console.log(res);
                setdel(false)

                APIService.SingleProvider({ _id: id })
                    .then((res) => {
                        // console.log("data is", res.data.data.name);
                        console.log(res);
                        setdata(res.data.data)
                        setvisible(false)
                        setdel(false)

                    })
                    .catch((err) => {
                        console.log(err);
                        setvisible(false)
                        setdel(false)

                    })


            })
            .catch((err) => {
                console.log(err);
                setdel(false)


            })
    }

    const handledelete2 = (id) => {



        console.log("hsdjhdk", id);
        let data = {
            _id: id,
            status: "false"
        }

        APIService.ProviderStatus(data)
            .then((res) => {
                console.log(res);
                setdel(false)

                APIService.SingleProvider({ _id: id })
                    .then((res) => {
                        // console.log("data is", res.data.data.name);
                        console.log(res);
                        setdata(res.data.data)
                        setvisible(false)
                        setdel(false)

                    })
                    .catch((err) => {
                        console.log(err);
                        setvisible(false)
                        setdel(false)

                    })


            })
            .catch((err) => {
                console.log(err);
                setdel(false)


            })
    }




    return (
        <>

            <>
                {/* Header Start */}
                <div className="container-fluid category">
                    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
                        <h3 className="text-white display-3 mb-4">Service Provider</h3>
                    </div>
                </div>
                {/* Header End */}
            </>

            <div className="row mt-5 container">
                <div className="col-md-1 "></div>
                <div className="col-md-10 ms-1">

                    {del ? (<ClipLoader size={100}></ClipLoader>) : (<table className="table table-bordered" style={{ backgroundColor: '#FFDBBB' }}>
                        <tr>
                            <th className="ps-3 text-dark">Name</th>
                            <th className="ps-5 text-dark">Email</th>
                            <th className="ps-2 text-dark">Contact</th>
                            <th className="ps-2 text-dark">Address</th>
                            <th className="ps-2 text-dark">Description</th>
                            <th className="ps-2 text-dark">Bussiness Contact</th>
                            <th className="ps-2 text-dark">Bussiness Email</th>
                            <th className="ps-2 text-dark">Image</th>
                            <th className="ps-2 text-dark">Action</th>



                        </tr>
                        {

                            data.map((el) => (
                                <tr>

                                    <td className="ps-3  text-dark" >{el.name}</td>
                                    <td className="ps-2 text-dark">{el.email}</td>
                                    <td className="ps-2 text-dark">{el.contact}</td>
                                    <td className="ps-2 text-dark">{el.address}</td>
                                    <td className="ps-2 text-dark">{el.description}</td>
                                    <td className="ps-2 text-dark">{el.businessContact}</td>
                                    <td className="ps-2 text-dark">{el.businessEmail}</td>
                                    <td className="ps-2 text-dark"><img src={ el.image} height={"100px"}></img></td>
                                

                                    <td className="ps-2 pe-3">
                                        <Link  to={"/admin/services/" + el._id} className="btn text-light me-4 mt-2" style={{ backgroundColor: "green", width: "75px" }}>Service</Link>
                                        <Link  to={"/admin/bookinga/" + el._id} className="btn text-light me-4 mt-2" style={{ backgroundColor: "green", width: "75px" }}>Booking</Link>

                                    </td>
                                      
                                </tr>
                            ))


                        }


                    </table>)}






                </div>
                <div className="col-md-1"></div>

            </div>











        </>
    )
}