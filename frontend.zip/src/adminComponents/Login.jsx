import axios from "axios";
import { useEffect, useState } from "react"
import APIService from "../APIService";
import { toast, ToastContainer } from "react-toastify";
import { useNavigate } from "react-router-dom";

export default function Login() {


    const [email, setemail] = useState('');
    const [password, setpassword] = useState('');

    const nav = useNavigate("")

    // const token = sessionStorage.getItem("token")


    const handSubmit = (e) => {

        e.preventDefault();
        let data = {
            email: email,
            password: password,

        }

        APIService.AdminLogin(data)
            .then((res) => {
                console.log(res);
                if (res.data.success) {
                    console.log("true", res.data.message);
                    toast.success(res.data.message, {
                        position: "top-center",
                        autoClose: 5000,
                        hideProgressBar: false,
                        closeOnClick: true,
                        pauseOnHover: true,
                        draggable: true,
                        progress: undefined,
                        theme: "dark",


                    })
                    sessionStorage.setItem("token", res.data.token)
                    sessionStorage.setItem("ServiceProviderid", res.data.data.serviceProviderId)
                    sessionStorage.setItem("customerid", res.data.data.customerId)
                    sessionStorage.setItem("userType", res.data.data.userType)

                }

                else {

                    console.log("false", res.data.message);
                    toast.error(res.data.message)


                }

                if (res.data.data.userType == 1) {
                    setTimeout(() => {
                        nav("/admin")
                    }, 3000)


                }
                else if (res.data.data.userType == 2) {


                    setTimeout(() => {
                        nav("/provider")
                    }, 3000)


                }

                else {

                    setTimeout(() => {
                        nav("/")
                    }, 3000)
                }




            })
            .catch((err) => {
                console.log(err);


            })

        setpassword('');
        setemail('');



    }




    return (
        <>

            <>
                {/* Header Start */}
                <div className="container-fluid bg-login ">
                    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
                        <h3 className="text-white display-3 mb-4">Login</h3>
                    </div>
                </div>
                {/* Header End */}
            </>

            <div className="container-fluid about  ">
                <div className="container py-5">
                    <div className="row mt-5">
                        <div className="col-md-4"></div>
                        <div className="col-md-4  ">
                            <ToastContainer
                                position="top-center"
                                autoClose={5000}
                                hideProgressBar={false}
                                newestOnTop={false}
                                closeOnClick
                                rtl={false}
                                pauseOnFocusLoss
                                draggable
                                pauseOnHover
                                theme="dark"
                            />

                            {/* <center><h2>Login</h2></center> */}

                            <form className=" login-form" onSubmit={handSubmit}>
                                <center><h2>Login</h2></center>
                                <div className="form-group">
                                    {/* <svg xmlns="http://www.w3.org/2000/svg" className="me-2" height="14" width="14" viewBox="0 0 512 512"><path fill="#ffffff" d="M64 112c-8.8 0-16 7.2-16 16l0 22.1L220.5 291.7c20.7 17 50.4 17 71.1 0L464 150.1l0-22.1c0-8.8-7.2-16-16-16L64 112zM48 212.2L48 384c0 8.8 7.2 16 16 16l384 0c8.8 0 16-7.2 16-16l0-171.8L322 328.8c-38.4 31.5-93.7 31.5-132 0L48 212.2zM0 128C0 92.7 28.7 64 64 64l384 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128z"/></svg> */}
                                    <label htmlFor="exampleInputEmail1">Email  </label>
                                    <input

                                        type="email"
                                        className="form-control"
                                        id="exampleInputEmail1"
                                        aria-describedby="emailHelp"
                                        placeholder="Enter email"

                                        value={email}
                                        onChange={(e) => { setemail(e.target.value) }}
                                    />

                                </div>
                                <div className="form-group mt-3">
                                    {/* <svg xmlns="http://www.w3.org/2000/svg" className="me-2" height="14" width="12.25" viewBox="0 0 448 512"><path fill="#fafafa" d="M144 144l0 48 160 0 0-48c0-44.2-35.8-80-80-80s-80 35.8-80 80zM80 192l0-48C80 64.5 144.5 0 224 0s144 64.5 144 144l0 48 16 0c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 256c0-35.3 28.7-64 64-64l16 0z"/></svg> */}
                                    <label htmlFor="exampleInputPassword1 " className="ms-2">Password</label>
                                    <input
                                        type="password"
                                        className="form-control"
                                        id="exampleInputPassword1"
                                        placeholder="Password"
                                        value={password}
                                        onChange={(e) => { setpassword(e.target.value) }}
                                    />
                                </div>

                                <button type="submit" className="btn btn-primary mt-3 mb-5" >
                                    Submit
                                </button>
                            </form>


                        </div>
                        <div className="col-md-4"></div>

                    </div>
                </div>
            </div>


        </>
    )
}