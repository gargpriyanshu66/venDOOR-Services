import { useEffect, useState } from "react"
import { ClipLoader } from "react-spinners"
import APIService from "../APIService";
import { toast } from "react-toastify";


export default function ManageReview() {
    const [data, setdata] = useState([""])
    const [visible, setvisible] = useState(false)
    useEffect(() => {

        setvisible(true)
        APIService.AllReviews()
            .then((res) => {
                console.log(res.data);
                setdata(res.data.data)
                setvisible(false)



            })
            .catch((err) => {
                console.log(err);
                setvisible(false)

            })



    }, []);

    const handledelte = (id) => {

        APIService.DeleteReview({ _id: id })
            .then((res) => {
                window.confirm("Are you want to  delete??")

                APIService.AllReviews()
                    .then((res) => {
                        console.log(res.data);
                        setdata(res.data.data)
                        setvisible(false)


                    })
                    .catch((err) => {
                        console.log(err);
                        setvisible(false)

                    })


            })
            .catch((err) => {
                toast.error("Something went wrong!!")

            })
    }


    const style = {
        textAlign: 'center'
    }
    return (
        <>

            <>
                {/* Header Start */}
                <div className="container-fluid review">
                    <div className="container text-center py-5" style={{ maxWidth: 900 }}>
                        <h3 className="text-white display-3 mb-4">Manage Review</h3>
                        
                    </div>
                </div>
                {/* Header End */}
            </>

            <div className="row container-fluid">
                <div className="col-md-2"></div>
                <div className="col-md-8" style={style}>

                    {visible ? (<ClipLoader size={100}></ClipLoader>) : (
                        <table className="table table-bordered mt-5" >
                            <tr>
                                <th className="text-dark">Sno</th>
                                <th className="text-dark">Customer Name</th>
                                <th className="text-dark">Service Name</th>
                                <th className="text-dark">Provider Name</th>
                                <th className="text-dark">Review</th>
                                <th className="text-dark">Rating</th>
                                <th className="text-dark">Action</th>
                            </tr>

                            {

                                data.map((el, index) => (
                                    <tr>
                                        <td>{index + 1}</td>
                                        <td>{el.customerId?.name}</td>
                                        <td>{el.serviceId?.name}</td>
                                        <td>{el.providerId?.name}</td>
                                        <td>{el.review}</td>
                                        <td>{el.rating}</td>
                                        <td>
                                            <button className="btn mt-2 " style={{ background: "red", width: "70px", color: "white", }} onClick={() => { handledelte(el._id) }} >Delete</button>
                                        </td>

                                    </tr>
                                ))
                            }

                        </table>
                    )}



                </div>
                <div className="col-md-2"></div>

            </div>




        </>
    )
}