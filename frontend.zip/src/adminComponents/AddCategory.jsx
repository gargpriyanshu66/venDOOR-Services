import { useState } from "react"
import APIService from "../APIService"
import { toast, ToastContainer } from "react-toastify"
import { useNavigate } from "react-router-dom"

export default function AddCategory() {
  const [name, setname] = useState("")
  const [description, setdescription] = useState("")
  const [image, setimage] = useState("")

  const nav = useNavigate()

  const handSubmit = (e) => {
    e.preventDefault();

    let data = new FormData()
    data.append("name", name)
    data.append("description", description)
    data.append("image", image)

    APIService.AddCategory(data)
      .then((res) => {
        console.log(res, data);
        if (res.data.success) {
          console.log("true", res.data.message);
          toast.success(res.data.message, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "dark",
          })

          setTimeout(() => {

            nav("/admin/manage")
          }, 1500)

        }
        else {

          console.log("false", res.data.message);
          toast.error(res.data.message)

        }


      })
      .catch((err) => {
        console.log(err);

      })

    setname("")
    setimage("")
    setdescription("")


  }
  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid bg-breadcrumb acategory">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Add Category</h3>
          </div>
        </div>
        {/* Header End */}
      </>

      <div className="container-fluid about py-5">
        <div className="container py-5">
          <div className="row mt-5">
            <div className="col-md-3"></div>
            <div className="col-md-6 " style={{ backgroundColor: "#D3D3D3" }}  >

              <center className="mt-5"><h2>Add Category</h2></center>

              <ToastContainer

                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="dark"

              />

              <form className="mt-4 ms-5 me-4" onSubmit={handSubmit}>
                <div className="form-group">
                  <label htmlFor="exampleInputEmail1" className="text-dark">Name</label>
                  <input
                    type="text"
                    className="form-control "
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                    value={name}
                    onChange={(e) => { setname(e.target.value) }}
                  />

                </div>
                <div className="form-group mt-3" >
                  <label htmlFor="exampleInputPassword1" className="text-dark">Description</label>
                  <input
                    type="text"
                    className="form-control"
                    id="exampleInputPassword1"
                    value={description}
                    onChange={(e) => { setdescription(e.target.value) }}
                  />
                </div>

                <div className="form-group mt-3">
                  <label htmlFor="exampleInputPassword1" className="text-dark">Image</label>
                  <input
                    type="file"
                    className="form-control"
                    id="exampleInputPassword1"

                    onChange={(e) => { setimage(e.target.files[0]) }}
                  />
                </div>

                <button type="submit" className="btn btn-primary mt-3 mb-5" style={{ width: "100px" }}>
                  Add
                </button>
              </form>


            </div>
            <div className="col-md-3"></div>

          </div>
        </div>
      </div>




    </>
  )
}