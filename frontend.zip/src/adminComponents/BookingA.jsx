import { useEffect, useState } from "react"
import APIService from "../APIService";
import { useParams } from "react-router-dom";
// import moment from 'moment';

export default function BookingA() {

  const [data, setdata] = useState([])
  const param = useParams()
  const id = param.id;
  console.log("service p", id);


  useEffect(() => {

    APIService.AllBookingAdmin({ providerId: id })

      .then((res) => {
        console.log("data is ", res.data.data)
        setdata(res.data.data)


      })
      .catch((err) => {
        console.log("error is", err);

      })


  }, [])
  return (
    <>

      <>
        {/* Header Start */}
        <div className="container-fluid booking">
          <div className="container text-center py-5" style={{ maxWidth: 900 }}>
            <h3 className="text-white display-3 mb-4">Bookings</h3>
          </div>
        </div>
        {/* Header End */}
      </>
      <div className="row mt-5 container">
        <div className="col-md-2 me-5"></div>
        <div className="col-md-9">
          <table className="table table-bordered " style={{ backgroundColor: '#808080' }}>
            <tr>
              <th className="ps-5 pt-3 text-light">Sno</th>
              <th className="ps-5 pt-3 text-light">Customer Name</th>
              <th className="ps-5 pt-3 text-light">Contact</th>
              <th className="ps-5 pt-3 text-light">Address</th>
              <th className="ps-5 pt-3 text-light">Time</th>
              <th className="ps-5 pt-3 text-light pe-5">Date</th>

            </tr>
            {

              data.map((el, index) => (
                <tr>
                  <td className="ps-5 pt-3 text-light">{index + 1}</td>
                  <td className="ps-5 pt-3 text-light">{el.customerName}</td>
                  <td className="ps-5 pt-3 text-light">{el.contact}</td>
                  <td className="ps-5 pt-3 text-light">{el.address}</td>
                  <td className="ps-5 pt-3 text-light">{el.time}</td>
                  {/* <td className="ps-5 pe-5 pt-3 text-light">{moment(el.date).format('MM/DD/YYYY')}</td> */}
                  <td className="ps-5 pt-3 text-light"> {new Date(el.date).toLocaleDateString("en-US", {
                                year: "numeric",
                                month: "2-digit",
                                day: "2-digit",
                              })}</td>

                </tr>
              ))

            }


          </table>
        </div>
      </div>
      <div className="col-md-1"></div>






    </>
  )
}